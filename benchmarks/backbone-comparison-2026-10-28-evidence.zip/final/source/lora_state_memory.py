"""Small learned adapters over a frozen text backbone; classify event effects.

Seven SET-day outcomes, CLEAR, and KEEP are learned labels. No text parser or
weekday-token filter runs at inference. The only state transition rules act on
the model's nine numerical output logits.
"""
import hashlib
import json

import torch
from torch import nn
from decoder_bridge import chat_render_options, reject_reserved_text, render_chat_template
from neural_state_memory import CLASSES, DAYS, ENCODER_SYSTEM, ENCODER_SUFFIX

OUTCOMES = (*DAYS, 'CLEAR', 'KEEP')


def render_event(tokenizer, event):
    if not isinstance(event, str) or not event.strip():
        raise ValueError('Nonempty natural event text required')
    reject_reserved_text(tokenizer, event, name='event')
    return render_chat_template(tokenizer, [{'role': 'system', 'content': ENCODER_SYSTEM},
        {'role': 'user', 'content': event + ENCODER_SUFFIX}],
        generation=True)


def tokenizer_render_signature(tokenizer):
    """Bind new adapters to the vocabulary, native template, and render settings.

    Local filesystem names are intentionally excluded: copying identical model
    files to another directory must not change compatibility.
    """
    vocabulary = tokenizer.get_vocab()
    if not isinstance(vocabulary, dict) or not vocabulary:
        raise ValueError('Tokenizer must expose a nonempty vocabulary')
    template = getattr(tokenizer, 'chat_template', None)
    payload = {'vocabulary': vocabulary, 'chat_template': template,
               'special_tokens': list(getattr(tokenizer, 'all_special_tokens', ())),
               'eos_token_id': tokenizer.eos_token_id, 'pad_token_id': tokenizer.pad_token_id,
               'padding_side': tokenizer.padding_side,
               'render_options': chat_render_options(tokenizer, generation=True),
               'event_example': render_event(tokenizer, 'This is a tokenizer compatibility check.'),
               'version': 1}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def tokenize_events(tokenizer, events, device):
    if getattr(tokenizer, 'padding_side', None) != 'right':
        raise ValueError('Event writer requires right padding for last-token pooling')
    if not isinstance(events, list) or not events:
        raise ValueError('A nonempty list of event strings is required')
    rendered = [render_event(tokenizer, event) for event in events]
    batch = tokenizer(rendered, padding=True, truncation=False, add_special_tokens=False, return_tensors='pt')
    if batch['input_ids'].shape[1] > 512:
        raise ValueError('Event exceeds512 tokens; no silent truncation')
    return {k: v.to(device) for k, v in batch.items() if k in ('input_ids', 'attention_mask')}


class LoraEventWriter(nn.Module):
    def __init__(self, backbone):
        super().__init__()
        self.backbone = backbone
        self.head = nn.Linear(backbone.config.hidden_size, len(OUTCOMES))

    def forward(self, input_ids, attention_mask):
        hidden = self.backbone(input_ids=input_ids, attention_mask=attention_mask,
                               use_cache=False, return_dict=True).last_hidden_state
        last = attention_mask.sum(-1) - 1
        features = hidden[torch.arange(len(hidden), device=hidden.device), last].float()
        return self.head(features)


def replay(outcomes):
    state, prefixes = 'UNKNOWN', []
    for outcome in outcomes:
        if outcome not in OUTCOMES:
            raise ValueError('Unknown predicted effect')
        if outcome != 'KEEP':
            state = 'UNKNOWN' if outcome == 'CLEAR' else outcome
        prefixes.append(state)
    return state, prefixes


def training_outcome(label):
    """Annotation translation for training/scoring only, never called by forward."""
    return label['day'] if label['action'] == 'SET' else label['action']


@torch.inference_mode()
def predict_events(model, tokenizer, events, batch_size=8):
    model.eval()
    device = next(model.head.parameters()).device
    result = {}
    for start in range(0, len(events), batch_size):
        selected = events[start:start + batch_size]
        logits = model(**tokenize_events(tokenizer, selected, device))
        result.update(zip(selected, [OUTCOMES[i] for i in logits.argmax(-1).tolist()]))
    return result


def score_examples(examples, predictions):
    from train_state_memory import summarize_records
    results, event_records, counts, states = [], [], {'events': 0, 'action_correct': 0, 'state_correct': 0,
                                                    'set_events': 0, 'set_day_correct': 0}, {}
    for example in examples:
        outcomes = [predictions[text] for text in example['events']]
        final, prefixes = replay(outcomes)
        states[example['id']] = final
        for i, (outcome, state, label) in enumerate(zip(outcomes, prefixes, example['event_labels'])):
            action = 'SET' if outcome in DAYS else outcome
            day = outcome if outcome in DAYS else None
            counts['events'] += 1
            counts['action_correct'] += action == label['action']
            counts['state_correct'] += state == label['state']
            if label['action'] == 'SET':
                counts['set_events'] += 1
                counts['set_day_correct'] += day == label['day']
            event_records.append({'id': example['id'], 'event_index': i,
                'expected_action': label['action'], 'predicted_action': action,
                'expected_day': label['day'], 'predicted_day': day,
                'expected_state': label['state'], 'predicted_state': state})
    for example in examples:
        donor = next(item for item in examples if item['answer'] != example['answer'])
        for mode, prediction in (('active_memory', states[example['id']]), ('zero_memory', 'UNKNOWN'),
                                 ('wrong_memory', states[donor['id']])):
            row = {'id': example['id'], 'mode': mode, 'expected': example['answer'],
                   'generated': prediction, 'correct': prediction == example['answer']}
            row.update({key: example[key] for key in ('cohort', 'pair_id', 'pair_variant')})
            if mode == 'wrong_memory':
                row.update(donor_id=donor['id'], donor_answer=donor['answer'])
            results.append(row)
    return {'records': results, 'event_records': event_records, 'event_metrics': counts, 'scores': summarize_records(results)}
