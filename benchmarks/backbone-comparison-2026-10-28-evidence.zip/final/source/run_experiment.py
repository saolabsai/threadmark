"""Small local Qwen integration/training experiment; no network or private data.

Default: one backward-pass smoke check. Use --steps 80 for a bounded toy run.
The byte fixture and synthetic weekday task are NOT a production tokenizer/eval.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import time

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from active_memory import ActiveMemoryConfig, ActiveMemoryModel
from decoder_bridge import assemble_decoder_inputs, freeze_decoder
from toy_data import DAYS, chunk_event, make_examples


ROOT = Path(__file__).resolve().parents[1]


def save_report(output, report):
    temporary = output / "report.json.tmp"
    temporary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    temporary.replace(output / "report.json")


def ingest(model, events):
    memory = model.initial_memory(1)
    for event in events:
        for ids in chunk_event(event, model.config.max_chunk_tokens):
            token_ids = torch.tensor([ids], device=memory.device, dtype=torch.long)
            memory = model.update(token_ids, memory)
    return memory


def digest_parameters(model):
    """Hash every base parameter, including its exact stored dtype bytes."""
    digest = hashlib.sha256()
    for name, parameter in model.named_parameters():
        digest.update(name.encode())
        digest.update(parameter.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def finite_gradient_norms(model):
    norms = {}
    for name, module in (("token_embedding", model.token_embedding),
                         ("candidate", model.candidate), ("gate", model.gate),
                         ("bridge", model.bridge), ("transformer", model.layers)):
        gradients = [p.grad for p in module.parameters() if p.grad is not None]
        if not gradients or not all(bool(torch.isfinite(g).all()) for g in gradients):
            raise RuntimeError(f"Missing or nonfinite gradients: {name}")
        norm = math.sqrt(sum(float(g.float().square().sum()) for g in gradients))
        if norm <= 0:
            raise RuntimeError(f"Zero gradient: {name}")
        norms[name] = norm
    return norms


@torch.inference_mode()
def evaluate(model, base, tokenizer, examples, modes):
    """Greedy output accuracy; score actual generated answers, not target loss."""
    model.eval()
    records = []
    for example in examples:
        memory = ingest(model, example["events"])
        prefix = model.project(memory)
        for mode in modes:
            query = example["query"]
            if mode == "active_memory":
                selected_prefix = prefix
            elif mode == "zero_memory":
                selected_prefix = model.project(torch.zeros_like(memory))
            elif mode == "full_history":
                selected_prefix = prefix[:, :0]
                query = "Conversation history:\n" + "\n".join(example["events"]) + "\n\n" + query
            elif mode == "recent_only":
                selected_prefix = prefix[:, :0]
                query = "Latest historical event:\n" + example["events"][-1] + "\n\n" + query
            else:
                raise ValueError(mode)
            # Target is used only to locate the template boundary, then removed.
            batch = assemble_decoder_inputs(base, tokenizer, selected_prefix, query, example["answer"])
            start = int(torch.nonzero(batch["labels"][0] != -100)[0])
            generated = base.generate(
                inputs_embeds=batch["inputs_embeds"][:, :start],
                attention_mask=batch["attention_mask"][:, :start],
                max_new_tokens=8, do_sample=False, use_cache=True,
                pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
            answer = tokenizer.decode(generated[0], skip_special_tokens=True).strip()
            normalized = answer.strip(". !\t\r\n").casefold()
            records.append({"id": example["id"], "mode": mode, "expected": example["answer"],
                            "generated": answer, "correct": normalized == example["answer"].casefold(),
                            "decoder_prompt_positions": start})
    scores = {mode: {"correct": sum(r["correct"] for r in records if r["mode"] == mode),
                     "total": len(examples)} for mode in modes}
    for score in scores.values():
        score["accuracy"] = score["correct"] / score["total"]
    return {"scores": scores, "records": records}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=ROOT.parent / "models/base-qwen3-0.6b")
    parser.add_argument("--output", type=Path, default=ROOT / "prototype/runs/smoke")
    parser.add_argument("--steps", type=int, default=0)
    parser.add_argument("--eval-count", type=int, default=12)
    parser.add_argument("--learning-rate", type=float, default=0.0003)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.steps < 0 or args.eval_count < 1 or not math.isfinite(args.learning_rate) or args.learning_rate <= 0:
        parser.error("steps must be nonnegative; eval-count and learning-rate must be positive")
    if args.output.exists():
        parser.error("output exists; choose a fresh directory to preserve earlier runs")
    args.output.mkdir(parents=True)
    torch.manual_seed(args.seed)
    torch.set_num_threads(4)
    config = ActiveMemoryConfig.from_design(ROOT / "design-config.json")
    dtype = torch.bfloat16 if args.device.startswith("cuda") and torch.cuda.is_bf16_supported() else torch.float32
    tokenizer = AutoTokenizer.from_pretrained(args.base, local_files_only=True, trust_remote_code=False)
    base = AutoModelForCausalLM.from_pretrained(
        args.base, torch_dtype=dtype, attn_implementation="sdpa", local_files_only=True,
        trust_remote_code=False, use_safetensors=True,
    ).to(args.device)
    freeze_decoder(base)
    model = ActiveMemoryModel(config).to(args.device)
    with torch.no_grad():
        embedding_std = float(base.get_input_embeddings().weight.float().std())
        model.bridge.weight.normal_(mean=0, std=embedding_std / math.sqrt(config.hidden_size))
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=0.01)
    assert {id(p) for p in model.parameters()}.isdisjoint({id(p) for p in base.parameters()})
    base_before = digest_parameters(base)
    training = make_examples("train", 64, args.seed)
    validation = make_examples("validation", args.eval_count, args.seed)
    testing = make_examples("test", args.eval_count, args.seed)
    (args.output / "data.json").write_text(json.dumps({"train": training, "validation": validation, "test": testing}, indent=2), encoding="utf-8")
    report = {
        "status": "running", "scope": "synthetic_weekday_prototype_not_product_evaluation",
        "seed": args.seed, "steps_requested": args.steps, "learning_rate": args.learning_rate,
        "trainable_parameters": sum(p.numel() for p in model.parameters()),
        "memory_shape": [1, config.memory_slots, config.hidden_size],
        "base_path": str(args.base), "base_dtype": str(dtype), "torch": torch.__version__,
        "device": torch.cuda.get_device_name(args.device) if args.device.startswith("cuda") else "cpu",
        "tokenizer": "UTF-8 byte fixture IDs 1..258 within proposed 32768 embedding table",
        "base_parameter_sha256_before": base_before,
        "training_examples": len(training), "held_out_examples_per_split": args.eval_count,
        "target_days": list(DAYS), "quality_claim": "No general usefulness or speedup established.",
    }
    model.train()
    smoke_memory = ingest(model, training[0]["events"])
    smoke_prefix = model.project(smoke_memory)
    batch = assemble_decoder_inputs(base, tokenizer, smoke_prefix, training[0]["query"], training[0]["answer"])
    loss = base(**batch, use_cache=False).loss
    if not bool(torch.isfinite(loss)):
        raise RuntimeError("Nonfinite initial response loss")
    loss.backward()
    report["smoke"] = {"loss": float(loss.detach()), "gradient_norms": finite_gradient_norms(model),
                       "base_has_no_gradients": all(p.grad is None for p in base.parameters()),
                       "prefix_shape": list(smoke_prefix.shape),
                       "memory_within_bounds": bool((smoke_memory.abs() <= 1).all())}
    optimizer.zero_grad(set_to_none=True)
    del batch, loss, smoke_memory, smoke_prefix
    report["status"] = "smoke_passed"
    save_report(args.output, report)
    print(json.dumps({"smoke": report["smoke"], "trainable_parameters": report["trainable_parameters"]}), flush=True)
    if args.steps:
        report["initial_validation"] = evaluate(model, base, tokenizer, validation, ["active_memory"])
        model.train()
        order = list(range(len(training)))
        rng = random.Random(args.seed)
        trajectory = []
        report["trajectory"] = trajectory
        report["status"] = "training"
        started = time.perf_counter()
        if args.device.startswith("cuda"):
            torch.cuda.reset_peak_memory_stats(args.device)
        for step in range(args.steps):
            if step % len(order) == 0:
                rng.shuffle(order)
            example = training[order[step % len(order)]]
            optimizer.zero_grad(set_to_none=True)
            memory = ingest(model, example["events"])
            prefix = model.project(memory)
            batch = assemble_decoder_inputs(base, tokenizer, prefix, example["query"], example["answer"])
            loss = base(**batch, use_cache=False).loss
            if not bool(torch.isfinite(loss)):
                raise RuntimeError(f"Nonfinite loss at step {step + 1}")
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
            optimizer.step()
            if step == 0 or (step + 1) % 10 == 0 or step + 1 == args.steps:
                row = {"step": step + 1, "loss": float(loss.detach()), "gradient_norm": float(norm),
                       "elapsed_seconds": time.perf_counter() - started}
                trajectory.append(row)
                report["steps_completed"] = step + 1
                save_report(args.output, report)
                print(json.dumps(row), flush=True)
            del batch, loss, memory, prefix
        report["training_seconds"] = time.perf_counter() - started
        report["trajectory"] = trajectory
        report["status"] = "training_complete_evaluation_pending"
        torch.save({"model_state_dict": model.state_dict(), "config": vars(config), "seed": args.seed,
                    "fixture_tokenizer": report["tokenizer"], "training_steps": args.steps}, args.output / "active_memory.pt")
        save_report(args.output, report)
        report["final_validation"] = evaluate(model, base, tokenizer, validation, ["active_memory", "zero_memory"])
        report["test"] = evaluate(model, base, tokenizer, testing,
                                  ["active_memory", "zero_memory", "full_history", "recent_only"])
        report["test_used_for_optimization"] = False
        report["peak_allocated_gpu_bytes"] = torch.cuda.max_memory_allocated(args.device) if args.device.startswith("cuda") else None
        report["peak_gpu_scope"] = "training plus final evaluation, excluding model load and initial validation"
    report["base_parameter_sha256_after"] = digest_parameters(base)
    report["base_parameters_unchanged"] = base_before == report["base_parameter_sha256_after"]
    report["base_has_no_gradients_after"] = all(p.grad is None for p in base.parameters())
    if not report["base_parameters_unchanged"] or not report["base_has_no_gradients_after"]:
        raise RuntimeError("Frozen decoder invariant failed")
    report["status"] = "completed"
    save_report(args.output, report)
    print(json.dumps({"report": str(args.output / "report.json"),
                      "base_parameters_unchanged": report["base_parameters_unchanged"],
                      "test_scores": report.get("test", {}).get("scores")}), flush=True)


if __name__ == "__main__":
    main()
