"""Training-only natural-message augmentation for learned event-effect heads.

Authored independently for training; this module imports no development/final
generator and reads no corpus files. Labels are attached by construction and
must be removed before inference. No text-parsing rule is supplied here.
"""
from collections import Counter
import hashlib
import json
import random


VERSION = "event-effect-augmentation-v1"
DAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
OUTCOMES = (*DAYS, "CLEAR", "KEEP")

SET_TEMPLATES = (
    "I give my approval to the invitation for {day}. This is my acceptance, so please enter our meeting on the calendar for that day.",
    "The actual reservation is now confirmed for {day}. The earlier idea of {other} has been withdrawn. We are agreed on the new booking.",
    "Your request to meet on {day} is no longer awaiting a decision: I approve it. That is the day we have settled on.",
    "Please treat this message as my binding confirmation of our meeting on {day}. All earlier alternatives are superseded.",
    "The sentence about {other} in my draft was not sent as an agreement. Here is my real decision: I confirm our meeting for {day}.",
    "Here is my actual acceptance, quoted for clarity: 'We have agreed to meet on {day}.' This is the real invitation decision, not sample wording.",
    "I am not declining the {day} invitation. I explicitly accept it and confirm that our meeting will be on {day}.",
    "I have finished checking availability. I accept {day} for this meeting and authorize that booking now; {other} is no longer an option.",
)

CLEAR_TEMPLATES = (
    "I am cancelling our meeting. Please remove the accepted booking for {day}; there is no replacement agreement in place.",
    "This is an actual cancellation notice for our meeting. The existing calendar reservation is void, and no new date has been accepted.",
    "Our previously confirmed meeting is called off. We might discuss {day} later, but nothing is booked or agreed at present.",
    "I withdraw my acceptance of the meeting and cancel it outright. Please leave the meeting without any agreed weekday until a new invitation is accepted.",
    "Please delete the current appointment: the meeting itself is cancelled. The mention of {other} was only an idea for a possible future invitation.",
    "My final decision is to cancel the scheduled meeting, including the {day} reservation. We have no active meeting arrangement now.",
    "The following is my real instruction, not a draft: 'Cancel our meeting and release the booking.' There is no accepted replacement date.",
    "The plan to retain the appointment was an unsent draft. I am now cancelling the actual meeting, with no new booking to take its place.",
)

KEEP_TEMPLATES = {
    "draft_confirmations": (
        "Please edit this unsent draft: 'I confirm our meeting for {day}.' It is proposed wording only and has not been issued as an acceptance. Our live arrangement stays as it was.",
        "The attachment contains a draft confirmation saying 'The booking for {day} is agreed.' Do not treat that draft as a real decision or modify the current meeting.",
        "I am considering writing 'Accepted: let us meet on {day}' in a later message. I have not sent that acceptance, and this editing request makes no schedule change.",
        "This is a request to proofread an unused confirmation for {day}. Its statement that the invitation is approved is draft text, not approval of the real invitation.",
        "In my scratch notes I wrote that {day} was confirmed. Those notes were never authorized; the actual meeting agreement must remain unchanged.",
        "A saved but unsent email says, 'We are booked for {day}.' I am reporting what the draft contains, not confirming that date for our meeting.",
    ),
    "fictional_quotes": (
        "For the writing exercise, the fictional customer says, 'I agree to the meeting on {day}.' This example is unrelated to our real booking and authorizes no change.",
        "The manual uses the sample line 'Your meeting for {day} is confirmed.' It describes an imaginary appointment, not the meeting between us.",
        "Please translate this demonstration sentence: 'Cancel the meeting on {day}.' It is only a translation task; I am not cancelling our actual appointment.",
        "An invented dialogue contains 'We accept {day}' followed by 'The meeting is booked.' We are discussing the dialogue, while our real arrangement stays untouched.",
        "I quoted a fictional cancellation notice in the training slide. Its reference to {day} is illustrative and does not withdraw any real agreement.",
        "The test data includes an example confirmation for {day}. That record is fabricated for testing and cannot establish a date for our own meeting.",
    ),
    "negated_changes": (
        "We have not agreed to meet on {day}. No acceptance of that proposed change has been given; leave the existing arrangement as it stands.",
        "I am not confirming the suggested {day} date. This message grants no approval and does not replace the current meeting agreement.",
        "Please note that our meeting is not cancelled. I am denying the cancellation rumor, and I am making no new weekday agreement.",
        "The assertion that I approved {day} is incorrect. I did not accept that proposed move, so the current agreement remains in force.",
        "There is no authorization here to cancel or reschedule the meeting. In particular, the mention of {day} is not confirmation of a new booking.",
        "I have neither accepted {day} nor cancelled the existing appointment. This clarification leaves the meeting arrangement unchanged.",
    ),
    "pending_proposals": (
        "Would it be possible to move our meeting to {day}? I am asking for a decision, not announcing one. Until you accept, retain the existing arrangement.",
        "I suggest {day} as another option. This suggestion is awaiting agreement and is not a replacement booking.",
        "Could you check whether {day} would suit you? I am only exploring availability; no change to our agreed meeting is authorized yet.",
        "I have submitted a request for {day}, but it is still unapproved. Please do not replace the existing meeting date on the basis of this request.",
        "The proposed {day} alternative remains on the waiting list for a response. There has been no acceptance, so the active arrangement should stay in place.",
        "I might prefer {day}, subject to your explicit agreement in a later message. This preference is not a confirmed rescheduling.",
    ),
    "rejected_moves": (
        "I decline the suggested move to {day}. I am rejecting that change only; the previously agreed meeting is still valid.",
        "The {day} alternative is not acceptable to me. Please discard the new proposal and preserve the existing appointment.",
        "Your request to switch to {day} has been refused. That refusal does not cancel or alter the meeting we already agreed to.",
        "Please close the unapproved proposal for {day} as rejected. Our original agreement continues without modification.",
        "I will not authorize the proposed {day} rescheduling. Keep the current booking; this is a denial of the new option.",
        "The attempt to replace the meeting with a {day} appointment has been rejected. There is no new agreement in this message.",
    ),
    "unrelated_weekday_facts": (
        "The printer maintenance is on {day}. That is a separate facilities event and has no effect on our meeting agreement.",
        "Our supplier sends invoices every {day}. I am sharing an administrative fact, not choosing a weekday for our meeting.",
        "My colleague's unrelated appointment on {day} is confirmed. That confirmation concerns a different event and does not modify ours.",
        "The cafeteria is closed on {day}. This notice contains no invitation decision and leaves our meeting as previously arranged.",
        "The room inspection scheduled for {day} was cancelled. That cancellation belongs to the inspection, not to our meeting.",
        "The example timetable lists {day} for a public lecture. It is unrelated background information and is not a date for our meeting.",
    ),
    "cancellation_requests": (
        "Could we cancel the meeting that mentions {day}? I am requesting approval to cancel, not issuing a cancellation. Until a decision arrives, leave the current agreement intact.",
        "I am considering whether to ask for cancellation. No cancellation has been made, and the present meeting arrangement remains active.",
        "Please review this proposed notice: 'Our meeting on {day} is cancelled.' The notice is an unapproved draft and must not be acted on.",
        "A request to cancel the meeting is pending review. It has not been accepted, so the appointment must remain as currently agreed.",
        "I reject the suggestion that we cancel our meeting. This rejection keeps the existing arrangement in place and creates no new date.",
        "The tentative cancellation proposal has been withdrawn before approval. Our actual appointment was never cancelled and should remain unchanged.",
    ),
    "administrative_receipts": (
        "I received your message about {day}. This is only an acknowledgment of receipt, not acceptance of the date you suggested.",
        "Thank you for sending the {day} option. I have filed it for review but have made no invitation decision and no change to our agreement.",
        "I have forwarded the question about {day} to my assistant. Forwarding a question is not confirmation or cancellation of the meeting.",
        "The calendar system logged the proposed {day} change. A log entry is not approval; the live agreement remains unchanged.",
        "I have read the request and will respond later. The reference to {day} has not been accepted by this acknowledgment.",
        "Your proposed update mentioning {day} is now in the review folder. This filing notice does not authorize any meeting change.",
    ),
}


def make_event_augmentation(seed=20261026, count=896):
    """Return ``{manifest, examples}``; each example has only text and outcome.

    Counts are multiples of112: 42 SET examples (six per weekday),14 CLEAR,
    and56 KEEP (eight conditions times seven weekdays) per block. These are
    training examples only, never a substitute for independent evaluation.
    """
    if type(seed) is not int or type(count) is not int:
        raise TypeError("seed and count must be integers")
    if count < 112 or count % 112:
        raise ValueError("count must be a positive multiple of112")
    rng = random.Random(f"{VERSION}:{seed}:{count}")
    examples, condition_counts = [], Counter()

    def add(template, day, outcome, condition):
        other = rng.choice([value for value in DAYS if value != day])
        sender = f"writer{rng.getrandbits(64):016x}@training.example"
        recipient = f"reader{rng.getrandbits(64):016x}@training.example"
        text = f"From: {sender}\nTo: {recipient}\nSubject: Meeting correspondence\n\n" + template.format(day=day, other=other)
        examples.append({"text": text, "outcome": outcome})
        condition_counts[condition] += 1

    for block in range(count // 112):
        for day in DAYS:
            for slot in range(6):
                add(SET_TEMPLATES[(block * 6 + slot) % len(SET_TEMPLATES)], day, day, "actual_confirmation")
        for slot in range(14):
            add(CLEAR_TEMPLATES[(block * 14 + slot) % len(CLEAR_TEMPLATES)], DAYS[slot % 7], "CLEAR", "actual_cancellation")
        for condition, templates in KEEP_TEMPLATES.items():
            for day in DAYS:
                add(templates[block % len(templates)], day, "KEEP", condition)
    rng.shuffle(examples)
    digest = hashlib.sha256(json.dumps(examples, sort_keys=True).encode()).hexdigest()
    manifest = {"generator": VERSION, "split": "training_augmentation_only", "seed": seed,
        "count": len(examples), "outcome_counts": dict(Counter(x["outcome"] for x in examples)),
        "condition_counts": dict(condition_counts), "examples_sha256": digest,
        "inference_field": "text", "training_label_field": "outcome",
        "source": "Independent authored training phrases; no development/final corpus imports or reads.",
        "limitations": ["Synthetic event-effect supervision for one meeting only.",
            "All active SET examples explicitly state a weekday; coreference remains outside this augmentation.",
            "Labels are attached by construction and must never enter inference prompts.",
            "Training performance on these phrases is not evidence of held-out generalization."]}
    return {"manifest": manifest, "examples": examples}


def make_augmented_events(seed=20261026, count=896):
    """Convenience API: list of ``{text: str, outcome: str}`` training records."""
    return make_event_augmentation(seed, count)["examples"]
