"""Natural-message fixture for a learned single-meeting state updater.

Visible messages contain ordinary From/To/Subject lines and email text, never
trusted action/status fields. Dense action/day/state annotations are separate
training/scoring data. Every state-changing confirmation names its weekday;
implicit acceptance, dates/times, and multiple simultaneous meetings are outside
this fixture. Final data requires an explicit locked-recipe hash and must not be
used to choose a model. These are synthetic template families, not real email.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
import random
import re


VERSION = "robust-state-v2"
GENERATION_REVISION = 2
DAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
CLASSES = (*DAYS, "UNKNOWN")
ACTIONS = ("KEEP", "SET", "CLEAR")
COHORTS = ("direct", "distractor_updates")
DEFAULT_COUNTS = {"train": 512, "development": 128, "final": 160}
DEFAULT_SEEDS = {"train": 314159, "development": 271828, "final": 20261026}
_PREFIX_SCHEMES = ("never_confirmed", "confirmed", "cancelled_then_reconfirmed", "accepted_replacement", "cancelled", "carry_forward")

_FAMILIES = {
    "train": {
        "proposal": (
            "Could we hold our meeting on {day}? Please reply before I reserve it.",
            "I propose {day} for the meeting. This is a suggestion and still needs agreement.",
            "Would {day} be suitable for our meeting? Nothing is booked yet.",
        ),
        "confirm": (
            "Confirmed: our meeting is on {day}. We have both agreed to that day.",
            "I accept {day} for our meeting. Please regard the meeting day as agreed.",
            "We have agreed that the meeting will take place on {day}.",
        ),
        "replace": (
            "The meeting has been rescheduled to {day}, and this replacement is confirmed.",
            "Our confirmed meeting day is now {day}; that replaces the previous arrangement.",
            "We have accepted the change: the meeting is now booked for {day}.",
        ),
        "reconfirm": (
            "The meeting is back on. We have confirmed {day} as its agreed day.",
            "We are arranging the meeting again, with {day} confirmed by both of us.",
            "I reconfirm that the meeting will be on {day}; this is a definite booking.",
        ),
        "cancel": (
            "The meeting is cancelled. There is no agreed replacement day.",
            "Please cancel our meeting and remove the booking. We have not agreed a new day.",
            "We are calling off this meeting; no meeting day is currently confirmed.",
        ),
        "pending": (
            "Can we move the meeting to {day}? This request has not been approved.",
            "I am considering {day} instead. Please do not change the meeting until we agree.",
            "A possible meeting change is {day}, but I cannot confirm it yet.",
        ),
        "reject": (
            "I do not accept a meeting change to {day}. This suggestion is rejected.",
            "No, {day} is not approved as a replacement for the meeting.",
            "I cannot agree to the suggested {day} move. Do not apply that change.",
        ),
        "draft": (
            "Unsent draft for review only: 'Our meeting is confirmed for {day}.' Do not send or apply this draft.",
            "I am testing some wording, not making a booking: 'The meeting is now on {day}.' This text remains an unsent draft.",
            "Please proofread this draft sentence: 'We agreed to meet on {day}.' It has not been sent and changes nothing.",
        ),
        "distractor": (
            "The office newsletter comes out on {day}. That is unrelated to our meeting schedule.",
            "A separate training class runs on {day}; it does not change our meeting.",
            "The equipment inspection is on {day}. I am only sharing information about that separate event.",
        ),
        "neutral": (
            "I have attached the agenda and the budget notes for our discussion.",
            "Please use the usual meeting link. I will bring the project notes.",
            "The supporting documents are available in our shared folder.",
        ),
        "queries": (
            "What weekday is currently agreed for our meeting? Reply with the weekday, or UNKNOWN if none is agreed.",
            "Give only the confirmed meeting weekday. Use UNKNOWN when there is no current agreement.",
        ),
    },
    "development": {
        "proposal": (
            "My tentative invitation is for {day}; I am waiting for your decision before fixing anything.",
            "Shall we consider {day} for this meeting? It is only an option at this point.",
            "I would like to suggest {day} as our meeting day, subject to your approval.",
        ),
        "confirm": (
            "Our meeting date is settled: {day}. You can enter that agreed day in the calendar.",
            "You have my approval for the meeting on {day}; the arrangement is final.",
            "The invitation for our meeting on {day} has been accepted by both participants.",
        ),
        "replace": (
            "The revised booking is settled for {day}. It supersedes the older meeting date.",
            "Both of us approved the revised schedule: our meeting will instead be on {day}.",
            "We have finalized a replacement day for the meeting: {day}.",
        ),
        "reconfirm": (
            "We have reinstated the meeting and settled on {day} for it.",
            "The meeting is going ahead again, with {day} accepted as the day.",
            "The renewed meeting invitation is approved for {day}.",
        ),
        "cancel": (
            "We will not hold this meeting. The booking is withdrawn, and no substitute date is settled.",
            "This meeting has been called off completely; a new day has not been chosen.",
            "The calendar entry for our meeting should be removed. We have no agreed day now.",
        ),
        "pending": (
            "Would a switch to {day} be worth discussing? It is not an accepted change.",
            "I have not approved {day} as an alternative; it is still under consideration.",
            "There is a request to shift the meeting to {day}. Please leave it pending until approval.",
        ),
        "reject": (
            "The suggested alternative, {day}, is declined. That move must not be made.",
            "I am rejecting the request to move the meeting to {day}.",
            "The answer to the proposed {day} change is no; it does not replace any agreement.",
        ),
        "draft": (
            "For editing only, my unpublished email says: 'The meeting is settled for {day}.' Nobody has sent this wording as a confirmation.",
            "This is a draft, not an actual schedule update: 'The agreed meeting day is {day}.' Please leave the schedule alone.",
            "Do not treat the following unsent message as an arrangement: 'I approve the meeting on {day}.' I only need copy edits.",
        ),
        "distractor": (
            "The building maintenance team visits on {day}; their appointment is separate from our meeting.",
            "An unrelated workshop is advertised for {day}. I am forwarding that detail for your information.",
            "Our report publication falls on {day}. This is not a change to the meeting date.",
        ),
        "neutral": (
            "The presentation slides have been revised and are ready for your review.",
            "I will take notes during the discussion and distribute them afterward.",
            "The project checklist is attached for use during the meeting.",
        ),
        "queries": (
            "Which weekday is the meeting actually scheduled by agreement? Answer only that day, or UNKNOWN if there is none.",
            "State the presently settled meeting day; write UNKNOWN if no day is settled.",
        ),
    },
    "final": {
        "proposal": (
            "Before we book anything, may I offer {day} as a candidate for the meeting?",
            "I am floating {day} for our meeting and need your response before it becomes definite.",
            "One date we could choose is {day}. This invitation is not yet an agreed booking.",
        ),
        "confirm": (
            "We have reached a definite arrangement for the meeting: it will be on {day}.",
            "Both calendars can now be updated for our meeting on {day}; agreement is complete.",
            "The meeting invitation has now been formally accepted for {day}.",
        ),
        "replace": (
            "The previous booking is superseded by our newly agreed meeting on {day}.",
            "We have jointly authorized the move, so {day} is the definite meeting day from now on.",
            "A replacement arrangement has been concluded: our meeting will be on {day} instead.",
        ),
        "reconfirm": (
            "Our meeting has been restored to the calendar, with {day} definitively agreed.",
            "We have made a fresh binding arrangement for the meeting on {day}.",
            "The renewed booking for our meeting is now final for {day}.",
        ),
        "cancel": (
            "Withdraw the meeting from our calendars. It will not proceed, and there is no replacement agreement.",
            "Our meeting arrangement is revoked in full. No new meeting day has been established.",
            "We have abandoned this meeting booking; nothing is scheduled by agreement anymore.",
        ),
        "pending": (
            "Could {day} become a substitute meeting day? This remains a request without assent.",
            "The idea of moving our meeting to {day} has no authorization yet.",
            "I am seeking consent for {day} as a possible replacement; consent has not been given.",
        ),
        "reject": (
            "I withhold consent for the proposed {day} substitution. That alteration is refused.",
            "The attempt to substitute {day} for our meeting day has been turned down.",
            "We will not adopt the suggested meeting move to {day}; that suggestion has failed.",
        ),
        "draft": (
            "This quotation is from an unissued message: 'Our meeting will definitely be on {day}.' It is a writing sample, not a real agreement.",
            "Here is unsent copy for proofreading: 'We have finalized our meeting for {day}.' No scheduling action should follow from this copy.",
            "I have not dispatched this draft announcement: 'The meeting day has been agreed as {day}.' It cannot be used as a confirmation.",
        ),
        "distractor": (
            "The library seminar is held on {day}. Its date has no bearing on our meeting arrangement.",
            "A notice says the fire-alarm drill occurs on {day}; that concerns a different activity.",
            "The supplier's unrelated product briefing is on {day}. This message merely passes along that information.",
        ),
        "neutral": (
            "I will circulate a written account of the decisions after our discussion.",
            "The reference material has been uploaded alongside the project outline.",
            "Please bring the latest estimates and any questions about the review.",
        ),
        "queries": (
            "Identify the weekday of the meeting's current definite arrangement. Return only the weekday, or UNKNOWN when none exists.",
            "Which weekday, if any, stands as the agreed meeting day now? Give only its name or UNKNOWN.",
        ),
    },
}

_NAMES = {
    "train": ("Mira", "Noah", "Sam", "Aditi", "Omar", "Leah", "Ben", "Jia"),
    "development": ("Elena", "Arun", "Iris", "Pavel", "Nadia", "Finn", "Zoe", "Ravi"),
    "final": ("Tessa", "Idris", "Mei", "Hugo", "Anika", "Soren", "Lina", "Dario"),
}
_TOPICS = ("budget review", "project planning", "design review", "team check-in", "research update", "delivery review")


def inference_inputs(example):
    """Allow only natural messages and the query across the inference boundary."""
    events, query = example.get("events"), example.get("query")
    if (not isinstance(events, list) or not events or any(not isinstance(e, str) or not e for e in events)
            or not isinstance(query, str) or not query):
        raise ValueError("Expected nonempty event strings and query")
    return {"events": list(events), "query": query}


def replay_labels(labels):
    """Validate dense annotations and return their final state (training/scoring)."""
    state = "UNKNOWN"
    for label in labels:
        if label["action"] == "SET" and label["day"] in DAYS:
            state = label["day"]
        elif label["action"] == "CLEAR" and label["day"] is None:
            state = "UNKNOWN"
        elif label["action"] != "KEEP" or label["day"] is not None:
            raise ValueError("Invalid action/day annotation")
        if label["state"] != state:
            raise ValueError("State annotation does not match incremental transitions")
    return state


def make_state_dataset(split, count=None, seed=None, *, final_recipe_sha256=None):
    """Build balanced paired examples; final generation requires a recipe lock.

    Counts must be positive multiples of 32. Each cohort has half the examples;
    all eight final states occur equally often within each cohort. Each pair
    differs in exactly one genuine state-changing/decisive message. Sender names,
    queries, previous events and later distractors are otherwise identical.
    ``event_labels`` and ``event_kinds`` are never inference inputs.
    """
    if split not in _FAMILIES:
        raise ValueError("split must be train, development, or final")
    count = DEFAULT_COUNTS[split] if count is None else count
    seed = DEFAULT_SEEDS[split] if seed is None else seed
    if type(count) is not int or count < 32 or count % 32:
        raise ValueError("count must be a positive multiple of 32")
    if type(seed) is not int:
        raise TypeError("seed must be an integer")
    if split == "final":
        if not isinstance(final_recipe_sha256, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", final_recipe_sha256):
            raise ValueError("Final generation requires the locked recipe/checkpoint SHA256")
        if count != DEFAULT_COUNTS["final"] or seed != DEFAULT_SEEDS["final"]:
            raise ValueError("Final count/seed are fixed by robust_state_eval_protocol.json")
    elif final_recipe_sha256 is not None:
        raise ValueError("Recipe lock is only applicable to final evaluation")
    rng = random.Random(f"{VERSION}:{split}:{seed}:{count}")
    family = _FAMILIES[split]
    examples = []
    pairs_per_cohort = count // 4
    for cohort in COHORTS:
        order = []
        for pair_index in range(pairs_per_cohort):
            if pair_index % len(CLASSES) == 0:
                order = list(CLASSES)
                rng.shuffle(order)
            targets = (order[pair_index % 8], order[(pair_index + 4) % 8])
            distractor_days = [day for day in DAYS if day not in targets]
            first_day, other_day = rng.sample(distractor_days, 2)
            names = rng.sample(_NAMES[split], 2)
            subject = rng.choice(_TOPICS)
            query = rng.choice(family["queries"])
            pair_id = f"{VERSION}-{split}-{seed}-{cohort}-{pair_index:05d}"

            def spec(kind, day=None, *, template=None, sender=None):
                text = (template or rng.choice(family[kind])).format(day=day)
                sender = rng.randrange(2) if sender is None else sender
                event = f"From: {names[sender]}\nTo: {names[1-sender]}\nSubject: {subject}\n\n{text}"
                action = "SET" if kind in {"confirm", "replace", "reconfirm"} else "CLEAR" if kind == "cancel" else "KEEP"
                return {"text": event, "kind": kind, "action": action, "day": day if action == "SET" else None}

            scheme = _PREFIX_SCHEMES[pair_index % len(_PREFIX_SCHEMES)]
            if scheme == "never_confirmed":
                prefix = [spec("proposal", first_day), spec("reject", first_day)]
            elif scheme == "confirmed":
                prefix = [spec("proposal", first_day), spec("confirm", first_day)]
            elif scheme == "cancelled_then_reconfirmed":
                prefix = [spec("confirm", first_day), spec("cancel"), spec("reconfirm", other_day)]
            elif scheme == "accepted_replacement":
                prefix = [spec("confirm", first_day), spec("pending", other_day), spec("replace", other_day)]
            elif scheme == "carry_forward":
                carry_day = rng.choice([day for day in targets if day != "UNKNOWN"])
                prefix = [spec("proposal", carry_day), spec("confirm", carry_day)]
            else:
                prefix = [spec("confirm", first_day), spec("cancel")]
            # Mention both possible known targets before the decisive message.
            # These are unrelated dates, shared across the counterfactual pair,
            # so the correct day is not the uniquely new weekday in a thread.
            candidate_days = [day for day in targets if day != "UNKNOWN"]
            if len(candidate_days) == 1:
                candidate_days.append(rng.choice([day for day in DAYS if day not in candidate_days]))
            rng.shuffle(candidate_days)
            prefix += [spec("distractor", day) for day in candidate_days]
            if cohort == "distractor_updates":
                prefix += [spec("distractor", first_day), spec("pending", other_day)]
                suffix = [spec("pending", first_day), spec("reject", first_day),
                          spec("draft", other_day), spec("distractor", other_day),
                          spec("distractor", candidate_days[0]), spec("draft", candidate_days[1])]
                # Vary distractor order and delay without leaking a target class.
                rng.shuffle(suffix)
                suffix += [spec(rng.choice(("neutral", "distractor", "draft")), other_day)
                           for _ in range(rng.randrange(3))]
            else:
                suffix = [spec("neutral")] if rng.choice((False, True)) else []
            positive_kind = rng.choice(("confirm", "replace", "reconfirm"))
            positive_template = rng.choice(family[positive_kind])
            sender = rng.randrange(2)
            prefix_state = "UNKNOWN"
            for item in prefix:
                if item["action"] == "SET":
                    prefix_state = item["day"]
                elif item["action"] == "CLEAR":
                    prefix_state = "UNKNOWN"
            unknown_kind = "pending" if prefix_state == "UNKNOWN" else "cancel"
            unknown_template = rng.choice(family[unknown_kind])
            for variant, target in enumerate(targets):
                if target == "UNKNOWN":
                    decisive = spec(unknown_kind, other_day, template=unknown_template, sender=sender)
                elif scheme == "carry_forward" and target == prefix_state:
                    # A still-pending alternative preserves the earlier agreed
                    # day. Its counterpart really confirms a new day (or clears
                    # the booking), so known final labels need not end in SET.
                    decisive = spec("pending", first_day, template=rng.choice(family["pending"]), sender=sender)
                else:
                    decisive = spec(positive_kind, target, template=positive_template, sender=sender)
                stream = prefix + [decisive] + suffix
                state = "UNKNOWN"
                labels = []
                for item in stream:
                    if item["action"] == "SET":
                        state = item["day"]
                    elif item["action"] == "CLEAR":
                        state = "UNKNOWN"
                    labels.append({"action": item["action"], "day": item["day"], "state": state})
                if state != target or replay_labels(labels) != target:
                    raise RuntimeError("Fixture state construction failed")
                examples.append({"id": f"{pair_id}-v{variant}", "split": split, "synthetic": True,
                                 "pair_id": pair_id, "pair_variant": variant, "cohort": cohort,
                                 "prefix_scheme": scheme, "events": [item["text"] for item in stream],
                                 "query": query, "answer": target, "event_labels": labels,
                                 "event_kinds": [item["kind"] for item in stream],
                                 "counterfactual_event_index": len(prefix)})
    rng.shuffle(examples)
    serialized_inputs = json.dumps([inference_inputs(e) for e in examples], ensure_ascii=False, sort_keys=True)
    family_bytes = json.dumps(family, ensure_ascii=False, sort_keys=True).encode("utf-8")
    manifest = {
        "generator": VERSION, "generation_revision": GENERATION_REVISION,
        "split": split, "seed": seed, "count": count,
        "classes": list(CLASSES), "cohorts": list(COHORTS), "pairs_per_cohort": pairs_per_cohort,
        "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "template_family_sha256": hashlib.sha256(family_bytes).hexdigest(),
        "inference_inputs_sha256": hashlib.sha256(serialized_inputs.encode("utf-8")).hexdigest(),
        "final_recipe_sha256": final_recipe_sha256,
        "answer_counts_by_cohort": {
            cohort: dict(Counter(e["answer"] for e in examples if e["cohort"] == cohort)) for cohort in COHORTS},
        "prefix_scheme_counts": dict(Counter(e["prefix_scheme"] for e in examples)),
        "event_action_counts": dict(Counter(label["action"] for e in examples for label in e["event_labels"])),
        "event_state_counts": dict(Counter(label["state"] for e in examples for label in e["event_labels"])),
        "event_kind_counts": dict(Counter(kind for e in examples for kind in e["event_kinds"])),
        "inference_fields": ["events", "query"],
        "training_scoring_only_fields": ["answer", "event_labels", "event_kinds", "prefix_scheme",
                                          "counterfactual_event_index", "pair_id", "pair_variant"],
        "anti_shortcut_construction": [
            "Both known candidate weekdays occur in unrelated KEEP messages before the decisive event.",
            "Challenge suffixes mention both candidates again in unrelated or explicitly unsent-draft KEEP messages.",
            "Carry-forward pairs include a known final agreement preserved by a decisive KEEP event.",
            "All nondecisive events, envelopes and query text are identical within each counterfactual pair.",
        ],
        "limitations": [
            "Synthetic finite templates, with separate wording families across splits; not a real-email benchmark.",
            "A single meeting, seven weekday names and UNKNOWN; no times, dates, time zones or concurrent entities.",
            "Every confirmed update explicitly names its weekday; implicit coreference is not supported.",
            "Draft wording is explicitly described as unsent in the message body; no trusted status labels are provided.",
            "KEEP events outnumber state changes; action counts are recorded, not claimed balanced.",
            "Final pairs are dependent observations; report pair success and cohort accuracy, not only aggregate accuracy.",
            "The final lock hash is an audit requirement, not a security boundary or proof of test-set isolation.",
        ],
    }
    return {"manifest": manifest, "examples": examples}


def make_state_examples(split, count=None, seed=None, *, final_recipe_sha256=None):
    return make_state_dataset(split, count, seed, final_recipe_sha256=final_recipe_sha256)["examples"]
