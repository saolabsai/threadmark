"""Task-specific learned weekday memory with a frozen language feature encoder.

Only event text reaches the encoder. There is no weekday/status extraction rule.
The learned action and day heads choose state updates; training labels never
enter ``encode`` or ``update``. This is not general-purpose language memory.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json

import torch
from torch import Tensor, nn
from torch.nn import functional as F


DAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
CLASSES = (*DAYS, "UNKNOWN")
ACTIONS = ("KEEP", "SET", "CLEAR")
ENCODER_SYSTEM = (
    "Read one new message about a meeting. Understand whether this message explicitly "
    "confirms an agreed meeting weekday, cancels the existing agreement, or leaves the "
    "agreement unchanged. A suggestion, pending request, rejection of a new suggestion, "
    "or an unrelated calendar fact does not change the agreement. A confirmed replacement "
    "does change it. Distinguish the agreed weekday from all other weekday mentions."
)
ENCODER_SUFFIX = "\n\nRepresent the effect of this new message on the existing meeting agreement."


def encoder_signature():
    return hashlib.sha256(json.dumps({"system": ENCODER_SYSTEM, "suffix": ENCODER_SUFFIX,
                                     "pooling": "last_position_and_masked_mean", "version": 1},
                                    sort_keys=True).encode()).hexdigest()


@dataclass(frozen=True)
class StateMemoryConfig:
    feature_size: int = 2048
    hidden_size: int = 256
    dropout: float = 0.05

    def __post_init__(self):
        if self.feature_size < 1 or self.hidden_size < 1 or not 0 <= self.dropout < 1:
            raise ValueError("Positive feature/hidden sizes and dropout in [0,1) required")


class FrozenEventEncoder:
    """Frozen Qwen backbone features; at most ``max_tokens`` per event, no truncation.

    The backbone can be ``AutoModel`` or a compatible test fixture. Right padding
    is masked. Returned features are ordinary detached FP32 CPU tensors so cached
    encoder features can subsequently participate in head training.
    """

    def __init__(self, backbone, tokenizer, max_tokens=512):
        self.backbone, self.tokenizer = backbone, tokenizer
        if max_tokens < 16:
            raise ValueError("max_tokens must be at least sixteen")
        self.max_tokens = max_tokens
        backbone.requires_grad_(False)
        backbone.eval()
        self.feature_size = 2 * backbone.config.hidden_size
        self.tokenizer.padding_side = "right"
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

    def render(self, event):
        if not isinstance(event, str) or not event.strip():
            raise ValueError("An event must be a nonempty string")
        if any(marker in event for marker in ("<|im_start|>", "<|im_end|>")):
            raise ValueError("Reserved chat boundary in event")
        return self.tokenizer.apply_chat_template(
            [{"role": "system", "content": ENCODER_SYSTEM},
             {"role": "user", "content": event + ENCODER_SUFFIX}],
            tokenize=False, add_generation_prompt=True, enable_thinking=False)

    def encode(self, events):
        if not isinstance(events, list) or not events:
            raise ValueError("encode requires a nonempty list of event strings")
        rendered = [self.render(event) for event in events]
        encoded = self.tokenizer(rendered, padding=True, truncation=False,
                                 return_tensors="pt", add_special_tokens=False)
        lengths = encoded["attention_mask"].sum(dim=1)
        if int(lengths.max()) > self.max_tokens:
            raise ValueError("Event exceeds encoder token budget; no content was silently truncated")
        device = next(self.backbone.parameters()).device
        encoded = {key: value.to(device) for key, value in encoded.items()
                   if key in ("input_ids", "attention_mask")}
        with torch.inference_mode():
            hidden = self.backbone(**encoded, use_cache=False, return_dict=True).last_hidden_state.float()
            mask = encoded["attention_mask"].unsqueeze(-1)
            mean = (hidden * mask).sum(dim=1) / mask.sum(dim=1)
            last = hidden[torch.arange(len(events), device=device), lengths.to(device) - 1]
            features = torch.cat((last, mean), dim=-1).cpu()
        # Clone outside inference_mode: the next linear operation saves features
        # for its trainable weight gradients.
        return features.clone()


class NeuralStateMemory(nn.Module):
    """Learn event actions and days, maintaining an eight-value probability state."""

    def __init__(self, config=None):
        super().__init__()
        self.config = config or StateMemoryConfig()
        self.register_buffer("feature_mean", torch.zeros(self.config.feature_size))
        self.register_buffer("feature_scale", torch.ones(self.config.feature_size))
        self.network = nn.Sequential(
            nn.Linear(self.config.feature_size, self.config.hidden_size), nn.GELU(),
            nn.Dropout(self.config.dropout),
            nn.Linear(self.config.hidden_size, self.config.hidden_size), nn.GELU())
        self.action_head = nn.Linear(self.config.hidden_size, len(ACTIONS))
        self.day_head = nn.Linear(self.config.hidden_size, len(DAYS))

    @torch.no_grad()
    def fit_normalizer(self, training_features):
        if training_features.ndim != 2 or training_features.shape[1] != self.config.feature_size:
            raise ValueError("Normalizer requires a [training events,feature_size] tensor")
        if len(training_features) < 2 or not bool(torch.isfinite(training_features).all()):
            raise ValueError("At least two finite training events are required")
        self.feature_mean.copy_(training_features.mean(dim=0))
        self.feature_scale.copy_(training_features.std(dim=0, unbiased=False).clamp_min(0.01))

    def initial_state(self, batch_size=1, device=None):
        if type(batch_size) is not int or batch_size < 1:
            raise ValueError("batch_size must be a positive integer")
        state = self.feature_mean.new_zeros((batch_size, len(CLASSES)), device=device)
        state[:, -1] = 1
        return state

    def event_logits(self, features):
        if features.shape[-1] != self.config.feature_size or not features.is_floating_point():
            raise ValueError("Features must be floating point with the configured last dimension")
        hidden = self.network((features - self.feature_mean) / self.feature_scale)
        return self.action_head(hidden), self.day_head(hidden)

    def update(self, features, state, *, hard=False):
        if features.ndim != 2 or state.shape != (features.shape[0], len(CLASSES)):
            raise ValueError("update expects [batch,features] and [batch,eight] state")
        action_logits, day_logits = self.event_logits(features)
        if hard:
            actions = F.one_hot(action_logits.argmax(-1), len(ACTIONS)).to(state.dtype)
            days = F.one_hot(day_logits.argmax(-1), len(DAYS)).to(state.dtype)
        else:
            actions, days = action_logits.softmax(-1), day_logits.softmax(-1)
        proposed = F.pad(days, (0, 1))
        cleared = self.initial_state(len(state), device=state.device)
        updated = actions[:, 0:1] * state + actions[:, 1:2] * proposed + actions[:, 2:3] * cleared
        return updated, action_logits, day_logits

    def forward(self, features, mask, *, hard=False):
        if features.ndim != 3 or mask.shape != features.shape[:2] or mask.dtype != torch.bool:
            raise ValueError("Expected [batch,events,features] and boolean [batch,events] mask")
        if features.shape[1] < 1 or not bool(mask.any(dim=1).all()):
            raise ValueError("Every thread needs at least one event")
        state = self.initial_state(len(features), features.device)
        states, action_logits, day_logits = [], [], []
        for position in range(features.shape[1]):
            proposed, action, day = self.update(features[:, position], state, hard=hard)
            state = torch.where(mask[:, position:position + 1], proposed, state)
            states.append(state)
            action_logits.append(action)
            day_logits.append(day)
        return {"state": state, "states": torch.stack(states, dim=1),
                "action_logits": torch.stack(action_logits, dim=1),
                "day_logits": torch.stack(day_logits, dim=1)}

    @torch.no_grad()
    def readout(self, state):
        if state.ndim != 2 or state.shape[1] != len(CLASSES):
            raise ValueError("readout requires a [batch,eight] state")
        return [CLASSES[index] for index in state.argmax(-1).tolist()]

    def checkpoint(self):
        return {"config": asdict(self.config), "model_state_dict": self.state_dict(),
                "classes": list(CLASSES), "actions": list(ACTIONS), "encoder_signature": encoder_signature()}


def supervised_loss(output, mask, actions, days, states, *, action_weights=None):
    """Training-only labels: event action, SET weekday, and state after each event."""
    if any(value.shape != mask.shape for value in (actions, days, states)):
        raise ValueError("Training labels must align with the event mask")
    action_loss = F.cross_entropy(output["action_logits"][mask], actions[mask], weight=action_weights)
    selected = mask & (actions == ACTIONS.index("SET"))
    day_loss = (F.cross_entropy(output["day_logits"][selected], days[selected]) if selected.any()
                else output["day_logits"].sum() * 0)
    state_loss = F.nll_loss(output["states"][mask].clamp_min(1e-8).log(), states[mask])
    return {"loss": action_loss + day_loss + state_loss,
            "action_loss": action_loss, "day_loss": day_loss, "state_loss": state_loss}
