"""Development-only LoRA event writer. Never opens final or calls an API."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import random
import time
import torch
from peft import LoraConfig, get_peft_model
from transformers import AutoModel, AutoTokenizer

from lora_state_memory import (LoraEventWriter, OUTCOMES, tokenize_events, predict_events,
                               score_examples, training_outcome, tokenizer_render_signature)
from neural_state_memory import encoder_signature
from robust_state_data import make_state_dataset
from run_experiment import save_report
from train_state_memory import validate_examples


def frozen_digest(model):
    digest = hashlib.sha256()
    for name, p in model.named_parameters():
        if not p.requires_grad:
            digest.update(name.encode())
            digest.update(p.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


# Historical Qwen checkpoints predate tokenizer binding. Only their original
# evaluated vocabulary/template is eligible for that legacy compatibility path.
LEGACY_QWEN_TOKENIZER_SIGNATURE = '8a512c28414f6ea220e09982f1997240956bfe3690f2d313bc9207896946be2b'


def validate_checkpoint_identity(initial, rank, frozen_hash, tokenizer_signature, model_type):
    if (initial['rank'] != rank or initial['outcomes'] != list(OUTCOMES)
        or initial['encoder_signature'] != encoder_signature()
        or initial['frozen_parameter_sha256'] != frozen_hash):
        raise ValueError('Initial checkpoint geometry, prompt or base mismatch')
    saved_signature = initial.get('tokenizer_render_signature')
    if saved_signature is not None:
        if saved_signature != tokenizer_signature:
            raise ValueError('Initial checkpoint tokenizer or native chat template mismatch')
    elif model_type != 'qwen3' or tokenizer_signature != LEGACY_QWEN_TOKENIZER_SIGNATURE:
        raise ValueError('Legacy checkpoint is only compatible with its original Qwen tokenizer')


def save_adapter_checkpoint(path, model, rank, epoch, key, frozen_hash, tokenizer_signature=None):
    payload = {'trainable_state_dict': {name: p.detach().cpu().clone() for name, p in model.named_parameters() if p.requires_grad},
        'rank': rank, 'epoch': epoch, 'encoder_signature': encoder_signature(), 'outcomes': list(OUTCOMES),
        'validation_key': list(key), 'frozen_parameter_sha256': frozen_hash}
    if tokenizer_signature is not None:
        payload.update(checkpoint_schema_version=2, tokenizer_render_signature=tokenizer_signature)
    temporary = path.with_suffix('.pt.tmp')
    torch.save(payload, temporary)
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, default=Path(__file__).resolve().parents[2] / 'models/base-qwen3-0.6b')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--batch-size', type=int, default=8)
    parser.add_argument('--rank', type=int, default=8)
    parser.add_argument('--learning-rate', type=float, default=0.0001)
    parser.add_argument('--seed', type=int, default=20261026)
    parser.add_argument('--train-count', type=int, default=512)
    parser.add_argument('--augment-events', type=int, default=0, help='Training-only independent event augmentation count')
    parser.add_argument('--initialize-from', type=Path, help='Continue from a previously selected LoRA checkpoint')
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Use a fresh run directory')
    if min(args.epochs, args.batch_size, args.rank) < 1 or not 0 < args.learning_rate < 0.1:
        parser.error('Invalid training settings')
    torch.set_num_threads(4)
    torch.manual_seed(args.seed)
    training = make_state_dataset('train', args.train_count, args.seed)
    development = make_state_dataset('development', 128, args.seed)
    validate_examples(training['examples'])
    validate_examples(development['examples'])
    annotations = {}
    for example in training['examples']:
        for event, label in zip(example['events'], example['event_labels']):
            target = training_outcome(label)
            if event in annotations and annotations[event] != target:
                raise ValueError('Identical event text has inconsistent supervision')
            annotations[event] = target
    augmentation = None
    if args.augment_events:
        from augment_event_data import make_event_augmentation
        augmentation = make_event_augmentation(seed=args.seed, count=args.augment_events)
        for row in augmentation['examples']:
            if row['outcome'] not in OUTCOMES or not isinstance(row['text'], str):
                raise ValueError('Invalid augmentation supervision')
            if row['text'] in annotations and annotations[row['text']] != row['outcome']:
                raise ValueError('Conflicting training augmentation')
            annotations[row['text']] = row['outcome']
    train_events = list(annotations)
    dev_events = list(dict.fromkeys(e for ex in development['examples'] for e in ex['events']))
    if set(train_events) & set(dev_events):
        raise ValueError('Train and development event text overlap')
    args.output.mkdir(parents=True)
    (args.output / 'training-data.json').write_text(json.dumps({'train': training, 'development': development}, indent=2), encoding='utf-8')
    if augmentation is not None:
        (args.output / 'training-augmentation.json').write_text(json.dumps(augmentation, indent=2), encoding='utf-8')
    tokenizer = AutoTokenizer.from_pretrained(args.base, local_files_only=True, trust_remote_code=False)
    tokenizer.padding_side = 'right'
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer_signature = tokenizer_render_signature(tokenizer)
    dtype = torch.bfloat16 if args.device.startswith('cuda') and torch.cuda.is_bf16_supported() else torch.float32
    base = AutoModel.from_pretrained(args.base, torch_dtype=dtype, attn_implementation='sdpa',
        local_files_only=True, trust_remote_code=False, use_safetensors=True).to(args.device)
    lora = LoraConfig(r=args.rank, lora_alpha=args.rank * 2, lora_dropout=0.05,
                      target_modules=['q_proj', 'v_proj', 'o_proj'], bias='none', task_type='FEATURE_EXTRACTION')
    model = LoraEventWriter(get_peft_model(base, lora)).to(args.device)
    before = frozen_digest(model)
    if args.initialize_from:
        initial = torch.load(args.initialize_from, map_location='cpu', weights_only=True)
        validate_checkpoint_identity(initial, args.rank, before, tokenizer_signature,
                                     getattr(base.config, 'model_type', None))
        learned = {name: p for name, p in model.named_parameters() if p.requires_grad}
        if set(learned) != set(initial['trainable_state_dict']):
            raise ValueError('Initial checkpoint learned parameter keys mismatch')
        with torch.no_grad():
            for name, p in learned.items():
                value = initial['trainable_state_dict'][name]
                if p.shape != value.shape or p.dtype != value.dtype or not bool(torch.isfinite(value).all()):
                    raise ValueError('Invalid initial learned tensor')
                p.copy_(value.to(p.device))
    report = {'status': 'training', 'architecture': 'lora_frozen_text_event_writer_nine_way_effect_head',
        'config': {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
        'train_count': len(training['examples']), 'development_count': len(development['examples']),
        'training_unique_events': len(train_events), 'development_unique_events': len(dev_events),
        'augmentation': augmentation['manifest'] if augmentation is not None else None,
        'initialized_checkpoint_sha256': hashlib.sha256(args.initialize_from.read_bytes()).hexdigest() if args.initialize_from else None,
        'trainable_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
        'frozen_parameters': sum(p.numel() for p in model.parameters() if not p.requires_grad),
        'frozen_parameter_sha256_before': before, 'encoder_signature': encoder_signature(),
        'tokenizer_render_signature': tokenizer_signature,
        'backbone_model_type': getattr(base.config, 'model_type', None),
        'backbone_hidden_size': base.config.hidden_size,
        'state_bytes_fp32': 32, 'trajectory': [], 'test_used_for_optimization': False,
        'limitations': ['Task-specific single-meeting weekday/UNKNOWN memory, not general email memory.',
            'A frozen text backbone plus trained LoRA adapters and event head processes every new message.',
            'Only natural event text enters inference. No weekday/status parsing, gold labels or event tags.',
            'Every update is predicted; seven weekday labels imply SET, CLEAR resets, KEEP preserves memory.',
            'Synthetic training supplies event-effect labels; real email and implicit acceptance remain untested.',
            'Observed synthetic accuracy is not a guarantee for future messages.'],
        'checkpoint_selection': 'Development final state, then prefix state, then event action accuracy.'}
    initial_predictions = predict_events(model, tokenizer, dev_events, args.batch_size)
    report['initial_development'] = score_examples(development['examples'], initial_predictions)
    initial_metrics = report['initial_development']['event_metrics']
    best = (report['initial_development']['scores']['active_memory']['accuracy'],
            initial_metrics['state_correct'] / initial_metrics['events'],
            initial_metrics['action_correct'] / initial_metrics['events'])
    save_adapter_checkpoint(args.output / 'lora-state.pt', model, args.rank, 0, best, before,
                            tokenizer_signature)
    report['development'] = report['initial_development']
    report['selected_epoch'] = 0
    save_report(args.output, report)
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(params, lr=args.learning_rate, weight_decay=0.01)
    counts = Counter(annotations.values())
    weights = torch.tensor([(len(train_events) / (len(OUTCOMES) * counts[o])) ** 0.5 for o in OUTCOMES], device=args.device)
    rng = random.Random(args.seed)
    started = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        model.train()
        order = list(train_events)
        rng.shuffle(order)
        losses = []
        for start in range(0, len(order), args.batch_size):
            selected = order[start:start + args.batch_size]
            labels = torch.tensor([OUTCOMES.index(annotations[e]) for e in selected], device=args.device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(**tokenize_events(tokenizer, selected, args.device))
            loss = torch.nn.functional.cross_entropy(logits, labels, weight=weights)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0, error_if_nonfinite=True)
            optimizer.step()
            losses.append(float(loss.detach()))
            if (start // args.batch_size + 1) % 100 == 0:
                print(json.dumps({'epoch': epoch, 'events_completed': min(start + args.batch_size, len(order)),
                                  'total': len(order)}), flush=True)
        checked = score_examples(development['examples'], predict_events(model, tokenizer, dev_events, args.batch_size))
        metrics = checked['event_metrics']
        key = (checked['scores']['active_memory']['accuracy'], metrics['state_correct'] / metrics['events'],
               metrics['action_correct'] / metrics['events'])
        if key > best:
            best = key
            save_adapter_checkpoint(args.output / 'lora-state.pt', model, args.rank, epoch, key, before,
                                    tokenizer_signature)
            report['development'] = checked
            report['selected_epoch'] = epoch
        row = {'epoch': epoch, 'mean_training_loss': sum(losses) / len(losses),
            'development_state_accuracy': key[0], 'development_prefix_state_accuracy': key[1],
            'development_action_accuracy': key[2], 'development_set_day_accuracy': metrics['set_day_correct'] / metrics['set_events'],
            'elapsed_seconds': time.perf_counter() - started}
        report['trajectory'].append(row)
        save_report(args.output, report)
        print(json.dumps(row), flush=True)
    report['training_seconds'] = time.perf_counter() - started
    report['selected_checkpoint'] = str(args.output / 'lora-state.pt')
    report['frozen_base_unchanged'] = frozen_digest(model) == before
    report['base_has_no_gradients'] = all(p.grad is None for p in model.parameters() if not p.requires_grad)
    if not report['frozen_base_unchanged'] or not report['base_has_no_gradients']:
        raise RuntimeError('Frozen backbone invariant failed')
    report['status'] = 'development_only_completed'
    save_report(args.output, report)
    print(json.dumps({'report': str(args.output / 'report.json'), 'development': report['development']['scores'], 'api_calls': 0}), flush=True)


if __name__ == '__main__':
    main()
