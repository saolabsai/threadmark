"""Connect learned memory to a compatible frozen text decoder without label leakage.

This single-example helper uses the tokenizer's actual chat template. It inserts
soft tokens after the complete system turn and before the user turn, preserving
all existing template tokens. No model is loaded and no forward pass is run here.

Training usage::

    freeze_decoder(base)
    batch = assemble_decoder_inputs(base, tokenizer, prefix, query, target)
    loss = base(**batch, use_cache=False).loss
    loss.backward()

The base forward must remain outside ``no_grad``/``inference_mode``: its frozen
operations still carry gradients from response loss into ``prefix``. A compatible
causal-LM loss shifts labels internally; do not shift the returned labels again.
"""

from __future__ import annotations

from typing import Any

import torch
from torch import Tensor, nn


DEFAULT_SYSTEM = (
    "Answer the question using the historical conversation represented by the "
    "memory tokens and any supplied context. Give only the requested answer."
)


def freeze_decoder(base: nn.Module) -> nn.Module:
    """Freeze every base parameter and disable dropout, preserving input autograd.

    Returns the same model. This does not install an inference-mode context or
    alter cache configuration; training callers should pass ``use_cache=False``.
    """
    base.requires_grad_(False)
    base.eval()
    return base


def chat_render_options(tokenizer: Any, *, generation: bool) -> dict[str, Any]:
    """Use the native template, disabling thinking only when it exposes that flag.

    Qwen3's evaluated rendering remains unchanged. SmolLM2 and other ordinary
    text templates receive no model-specific option. Lightweight legacy test
    tokenizers without a template attribute retain the previous options.
    """
    options = {"tokenize": False, "add_generation_prompt": generation}
    template = getattr(tokenizer, "chat_template", None)
    if isinstance(template, dict):
        template = tokenizer.get_chat_template()
    if template is None or (isinstance(template, str) and "enable_thinking" in template):
        options["enable_thinking"] = False
    return options


def reject_reserved_text(tokenizer: Any, text: str, *, name: str) -> None:
    """Reject serialized role/special tokens using this tokenizer's own markers."""
    markers = {"<|im_start|>", "<|im_end|>"}
    markers.update(
        token for token in getattr(tokenizer, "all_special_tokens", ())
        if isinstance(token, str) and token
    )
    if any(marker in text for marker in markers):
        raise ValueError(f"{name} contains a reserved tokenizer/chat-boundary marker")


def render_chat_template(
    tokenizer: Any, messages: list[dict[str, str]], *, generation: bool
) -> str:
    text = tokenizer.apply_chat_template(
        messages, **chat_render_options(tokenizer, generation=generation)
    )
    if not isinstance(text, str) or not text:
        raise ValueError("The tokenizer must render a nonempty chat-template string")
    return text


def _encode(tokenizer: Any, text: str) -> list[int]:
    ids = tokenizer.encode(text, add_special_tokens=False)
    if not isinstance(ids, list) or not ids or any(type(i) is not int or i < 0 for i in ids):
        raise ValueError("The tokenizer must return a nonempty list of token IDs")
    return ids


def assemble_decoder_inputs(
    base: nn.Module,
    tokenizer: Any,
    prefix: Tensor,
    query: str,
    target: str,
    system: str = DEFAULT_SYSTEM,
) -> dict[str, Tensor]:
    """Return single-example ``inputs_embeds``, ``attention_mask``, and ``labels``.

    ``prefix`` is floating point with shape ``[K,D]`` or ``[1,K,D]``. ``K=0`` is
    supported for text-only baselines. Its device/dtype are converted to those
    of the base embedding table using differentiable ``Tensor.to``. ``query``
    appears once, and memory must represent only history preceding that query.

    The returned tensors have shapes ``[1,T,D]``, ``[1,T]``, and ``[1,T]``. Every
    context, soft-token, and assistant-framing label is -100. Labels supervise
    target content and its template-provided end-of-message token; any trailing
    template formatting is masked. Standard causal masking inside the decoder and its
    internal one-token label shift ensure a target token cannot predict itself.

    This supports native text templates with exact system/prompt boundaries,
    including the evaluated Qwen3 and SmolLM2 ChatML layouts, not arbitrary
    tool/multimodal templates. Exact system/prompt token boundaries
    must exist; incompatible templates fail instead of silently misaligning
    labels. The native template's content normalization (such as stripping an assistant
    reply's leading newlines) remains in effect. Embedded chat-boundary strings
    are rejected because they would create additional serialized turns.

    Call ``freeze_decoder`` first. This helper does not execute the base forward
    or detach the learned prefix. The first non--100 label is the split point
    for a generation-only prompt: slice embeddings/mask before that position.
    """
    for name, value in (("system", system), ("query", query), ("target", target)):
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{name} must be a nonempty string")
        reject_reserved_text(tokenizer, value, name=name)

    if not isinstance(prefix, Tensor) or not prefix.is_floating_point():
        raise ValueError("prefix must be a floating-point tensor")
    if prefix.ndim == 2:
        prefix = prefix.unsqueeze(0)
    if prefix.ndim != 3 or prefix.shape[0] != 1:
        raise ValueError("prefix must have shape [K,D] or [1,K,D]")
    if any(parameter.requires_grad for parameter in base.parameters()):
        raise ValueError("Call freeze_decoder(base) before assembling training inputs")

    embedding = base.get_input_embeddings()
    if embedding is None or not hasattr(embedding, "weight"):
        raise ValueError("The decoder must expose a token embedding table")
    weight = embedding.weight
    if weight.ndim != 2 or prefix.shape[-1] != weight.shape[1]:
        raise ValueError("prefix width must equal the decoder's token embedding width")
    if weight.device.type == "meta":
        raise ValueError("The decoder embedding table must be materialized on a device")
    if not torch.isfinite(prefix).all():
        raise ValueError("prefix must contain only finite values")

    system_message = {"role": "system", "content": system}
    messages = [system_message, {"role": "user", "content": query}]
    system_text = render_chat_template(tokenizer, [system_message], generation=False)
    prompt_text = render_chat_template(tokenizer, messages, generation=True)
    full_text = render_chat_template(
        tokenizer,
        messages + [{"role": "assistant", "content": target, "reasoning_content": ""}],
        generation=False,
    )
    if not prompt_text.startswith(system_text) or not full_text.startswith(prompt_text):
        raise ValueError("Chat template does not preserve the required system/prompt boundaries")

    system_ids, prompt_ids, full_ids = (
        _encode(tokenizer, text) for text in (system_text, prompt_text, full_text)
    )
    if prompt_ids[:len(system_ids)] != system_ids or full_ids[:len(prompt_ids)] != prompt_ids:
        raise ValueError("Tokenization merges across the required system/prompt boundary")
    if len(system_ids) >= len(prompt_ids) or len(prompt_ids) >= len(full_ids):
        raise ValueError("The rendered example must include system, query, and target tokens")
    if max(full_ids) >= weight.shape[0]:
        raise ValueError("Tokenizer IDs exceed the decoder's embedding vocabulary")

    eos_id = tokenizer.eos_token_id
    if type(eos_id) is not int or eos_id < 0:
        raise ValueError("The tokenizer must define a valid end-of-message token ID")
    eos_positions = [i for i in range(len(prompt_ids), len(full_ids)) if full_ids[i] == eos_id]
    if len(eos_positions) != 1 or eos_positions[0] <= len(prompt_ids):
        raise ValueError("The target must contain text followed by exactly one template EOS")
    answer_end = eos_positions[0] + 1

    device = weight.device
    ids = torch.tensor([full_ids], dtype=torch.long, device=device)
    text_embeddings = embedding(ids)
    prefix = prefix.to(device=device, dtype=text_embeddings.dtype)
    if not torch.isfinite(prefix).all():
        raise ValueError("prefix overflows the decoder embedding dtype")
    boundary = len(system_ids)
    inputs_embeds = torch.cat(
        (text_embeddings[:, :boundary], prefix, text_embeddings[:, boundary:]), dim=1
    )
    length = len(full_ids) + prefix.shape[1]
    model_limit = getattr(getattr(base, "config", None), "max_position_embeddings", None)
    if isinstance(model_limit, int) and length > model_limit:
        raise ValueError(f"Example has {length} positions, exceeding decoder limit {model_limit}")
    attention_mask = torch.ones((1, length), dtype=torch.long, device=device)
    labels = torch.full((1, length), -100, dtype=torch.long, device=device)
    answer_start = len(prompt_ids) + prefix.shape[1]
    answer_length = answer_end - len(prompt_ids)
    labels[:, answer_start:answer_start + answer_length] = ids[:, len(prompt_ids):answer_end]

    # Explicit integration invariants: labels align with teacher-forced inputs;
    # prefix/context and the template's post-EOS formatting remain loss-masked.
    if inputs_embeds.shape != (1, length, weight.shape[1]):
        raise RuntimeError("Unexpected decoder embedding shape")
    if labels.shape != attention_mask.shape or not (labels[:, :answer_start] == -100).all():
        raise RuntimeError("Context labels were not fully masked")
    if not (labels[:, answer_start + answer_length:] == -100).all():
        raise RuntimeError("Post-EOS formatting was not masked")
    if int((labels != -100).sum()) != answer_length or labels[0, answer_start + answer_length - 1] != eos_id:
        raise RuntimeError("Reply labels do not preserve the template EOS")
    return {"inputs_embeds": inputs_embeds, "attention_mask": attention_mask, "labels": labels}
