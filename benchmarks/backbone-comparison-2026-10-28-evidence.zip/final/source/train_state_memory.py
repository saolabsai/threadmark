"""Train a task-specific neural state writer on frozen local Qwen event features.

No network, credentials, paid APIs, status parsing, or gold labels at inference.
Final examples are generated only after selecting the checkpoint on development.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import random
import time

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from decoder_bridge import assemble_decoder_inputs, freeze_decoder
from neural_state_memory import (ACTIONS, CLASSES, DAYS, FrozenEventEncoder, NeuralStateMemory,
                                 StateMemoryConfig, encoder_signature, supervised_loss)
from run_experiment import digest_parameters, save_report


ROOT = Path(__file__).resolve().parents[1]


def inference_inputs(example):
    events, query = example.get("events"), example.get("query")
    if (not isinstance(events, list) or not events or any(not isinstance(e, str) or not e.strip() for e in events)
            or not isinstance(query, str) or not query.strip()):
        raise ValueError("Inference requires nonempty event strings and a query")
    return {"events": list(events), "query": query}


def validate_examples(examples):
    if not isinstance(examples, list) or not examples:
        raise ValueError("A nonempty example list is required")
    seen = set()
    for example in examples:
        inputs = inference_inputs(example)
        if example.get("synthetic") is not True or example.get("answer") not in CLASSES:
            raise ValueError("Only declared synthetic weekday/UNKNOWN examples are supported")
        identifier = example.get("id")
        if not isinstance(identifier, str) or not identifier or identifier in seen:
            raise ValueError("Unique nonempty example ids are required")
        seen.add(identifier)
        labels = example.get("event_labels")
        if not isinstance(labels, list) or len(labels) != len(inputs["events"]):
            raise ValueError("Training/scoring annotations must align with events")
        state = "UNKNOWN"
        for label in labels:
            if label.get("action") not in ACTIONS:
                raise ValueError("Unknown annotated action")
            if label["action"] == "SET":
                if label.get("day") not in DAYS:
                    raise ValueError("SET needs an annotated weekday")
                state = label["day"]
            else:
                if label.get("day") is not None:
                    raise ValueError("Only SET may carry a weekday label")
                if label["action"] == "CLEAR":
                    state = "UNKNOWN"
            if label.get("state") != state:
                raise ValueError("Inconsistent intermediate state annotation")
        if state != example["answer"]:
            raise ValueError("Final state annotation does not match answer")
    return examples


def synchronize(device):
    if torch.device(device).type == "cuda":
        torch.cuda.synchronize(device)


def load_reusable_features(directory, base_hash, feature_size):
    """Reuse only completed development-run features bound to this encoder/base.

    Selection is later by exact event text, never labels, ids, or approximate
    matches. Final-test feature caches are deliberately not considered.
    """
    directory = Path(directory)
    report = json.loads((directory / "report.json").read_text(encoding="utf-8"))
    if (report.get("status") != "development_only_completed" or report.get("test")
            or report.get("frozen_base_unchanged") is not True
            or report.get("base_parameter_sha256_before") != base_hash
            or report.get("encoder_signature") != encoder_signature()):
        raise ValueError("Reusable features require a completed development run with the identical frozen base and encoder")
    combined = {}
    for filename in ("train-features.pt", "development-features.pt"):
        payload = torch.load(directory / filename, map_location="cpu", weights_only=True)
        if payload.get("encoder_signature") != encoder_signature():
            raise ValueError("Cached encoder signature differs")
        if payload.get("base_parameter_sha256", base_hash) != base_hash:
            raise ValueError("Cached frozen-base hash differs")
        features = payload.get("features")
        if not isinstance(features, dict):
            raise ValueError("Cached features must map exact event text to tensors")
        for event, value in features.items():
            if (not isinstance(event, str) or not event or not isinstance(value, torch.Tensor)
                    or value.shape != (feature_size,) or not value.is_floating_point()
                    or not bool(torch.isfinite(value).all())):
                raise ValueError("Malformed or incompatible cached event feature")
            combined.setdefault(event, value.float())
    return combined


def cache_features(encoder, examples, batch_size, device, reusable=None):
    """Encode event strings only; sharing identical event content is label-free."""
    events = list(dict.fromkeys(event for example in examples for event in inference_inputs(example)["events"]))
    reusable = reusable or {}
    cache = {event: reusable[event] for event in events if event in reusable}
    reused = len(cache)
    missing = [event for event in events if event not in cache]
    synchronize(device)
    started = time.perf_counter()
    for start in range(0, len(missing), batch_size):
        selected = missing[start:start + batch_size]
        features = encoder.encode(selected)
        cache.update(zip(selected, features.unbind(0)))
        if start == 0 or (start // batch_size + 1) % 25 == 0:
            print(json.dumps({"feature_events_completed": reused + min(start + batch_size, len(missing)),
                              "feature_events_total": len(events)}), flush=True)
    synchronize(device)
    return cache, {"unique_events": len(events), "event_occurrences": sum(len(x["events"]) for x in examples),
                   "reused_exact_events": reused, "encoded_events": len(missing),
                   "seconds": time.perf_counter() - started, "batch_size": batch_size,
                   "timing_scope": "Batched unique-event feature extraction; not per-request latency"}


def collate(examples, cache, device):
    maximum = max(len(inference_inputs(x)["events"]) for x in examples)
    width = next(iter(cache.values())).numel()
    features = torch.zeros(len(examples), maximum, width, device=device)
    mask = torch.zeros(len(examples), maximum, dtype=torch.bool, device=device)
    actions = torch.zeros(len(examples), maximum, dtype=torch.long, device=device)
    days = torch.zeros_like(actions)
    states = torch.zeros_like(actions)
    for row, example in enumerate(examples):
        events = inference_inputs(example)["events"]
        features[row, :len(events)] = torch.stack([cache[event] for event in events]).to(device)
        mask[row, :len(events)] = True
        # Labels are returned separately and never passed to the neural model.
        for column, label in enumerate(example["event_labels"]):
            actions[row, column] = ACTIONS.index(label["action"])
            days[row, column] = DAYS.index(label["day"]) if label["day"] is not None else 0
            states[row, column] = CLASSES.index(label["state"])
    return features, mask, actions, days, states


def normalize(text):
    return text.strip(". !\t\r\n").casefold()


@torch.no_grad()
def evaluate(model, examples, cache, batch_size=64):
    model.eval()
    device = model.feature_mean.device
    records, event_records, outputs = [], [], []
    sums = Counter()
    per_action = {action: Counter() for action in ACTIONS}
    started = time.perf_counter()
    for start in range(0, len(examples), batch_size):
        selected = examples[start:start + batch_size]
        features, mask, actions, days, states = collate(selected, cache, device)
        result = model(features, mask, hard=True)
        outputs.extend(result["state"].cpu().unbind(0))
        for row, example in enumerate(selected):
            for position, label in enumerate(example["event_labels"]):
                predicted_action = ACTIONS[int(result["action_logits"][row, position].argmax())]
                predicted_day = DAYS[int(result["day_logits"][row, position].argmax())]
                predicted_state = CLASSES[int(result["states"][row, position].argmax())]
                sums["events"] += 1
                sums["action_correct"] += predicted_action == label["action"]
                sums["state_correct"] += predicted_state == label["state"]
                per_action[label["action"]]["total"] += 1
                per_action[label["action"]]["correct"] += predicted_action == label["action"]
                if label["action"] == "SET":
                    sums["set_events"] += 1
                    sums["set_day_correct"] += predicted_day == label["day"]
                event_records.append({"id": example["id"], "event_index": position,
                    "expected_action": label["action"], "predicted_action": predicted_action,
                    "expected_day": label["day"], "predicted_day": predicted_day,
                    "expected_state": label["state"], "predicted_state": predicted_state})
    synchronize(device)
    for index, example in enumerate(examples):
        donor = next((j for j in range(len(examples)) if examples[j]["answer"] != example["answer"]), None)
        if donor is None:
            raise ValueError("Wrong-state control requires different answers")
        predictions = {"active_memory": CLASSES[int(outputs[index].argmax())],
                       "zero_memory": "UNKNOWN", "wrong_memory": CLASSES[int(outputs[donor].argmax())]}
        for mode, generated in predictions.items():
            record = {"id": example["id"], "mode": mode, "expected": example["answer"],
                      "generated": generated, "correct": normalize(generated) == normalize(example["answer"])}
            for key in ("cohort", "pair_id", "pair_variant"):
                if key in example:
                    record[key] = example[key]
            if mode == "wrong_memory":
                record.update(donor_id=examples[donor]["id"], donor_answer=examples[donor]["answer"])
            records.append(record)
    return {"scores": summarize_records(records), "records": records, "event_records": event_records,
            "event_metrics": dict(sums), "head_evaluation_seconds": time.perf_counter() - started,
            "action_metrics": {key: dict(value) for key, value in per_action.items()},
            "class_metrics": {label: {"correct": sum(r["correct"] for r in records if r["mode"] == "active_memory" and r["expected"] == label),
                                      "total": sum(r["mode"] == "active_memory" and r["expected"] == label for r in records)} for label in CLASSES},
            "timing_scope": "Cached-feature head evaluation and scoring; excludes text feature extraction"}


def summarize_records(records):
    result = {}
    for mode in dict.fromkeys(x["mode"] for x in records):
        selected = [x for x in records if x["mode"] == mode]
        correct = sum(x["correct"] for x in selected)
        result[mode] = {"correct": correct, "total": len(selected), "accuracy": correct / len(selected)}
    return result


@torch.inference_mode()
def full_history_records(base, tokenizer, examples):
    records = []
    for index, example in enumerate(examples):
        inputs = inference_inputs(example)
        query = "Conversation history:\n" + "\n".join(inputs["events"]) + "\n\n" + inputs["query"]
        prefix = base.get_input_embeddings().weight.new_empty(1, 0, base.config.hidden_size)
        batch = assemble_decoder_inputs(base, tokenizer, prefix, query, "placeholder")
        end = int(torch.nonzero(batch["labels"][0] != -100)[0])
        generated = base.generate(inputs_embeds=batch["inputs_embeds"][:, :end],
            attention_mask=batch["attention_mask"][:, :end], max_new_tokens=8,
            do_sample=False, use_cache=True, pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id)
        text = tokenizer.decode(generated[0], skip_special_tokens=True).strip()
        record = {"id": example["id"], "mode": "full_history", "expected": example["answer"],
                  "generated": text, "correct": normalize(text) == normalize(example["answer"]),
                  "decoder_prompt_positions": end}
        for key in ("cohort", "pair_id", "pair_variant"):
            if key in example:
                record[key] = example[key]
        records.append(record)
        if (index + 1) % 32 == 0:
            print(json.dumps({"full_history_completed": index + 1, "total": len(examples)}), flush=True)
    return records


def save_checkpoint(path, model, epoch, key):
    payload = model.checkpoint()
    payload.update(epoch=epoch, validation_key=list(key))
    temporary = path.with_suffix(".pt.tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def export_api_cases(output, examples, evaluation, report):
    predictions = {(r["id"], r["mode"]): r["generated"] for r in evaluation["records"]}
    cases = []
    for example in examples:
        inputs = inference_inputs(example)
        arms = {"full_history": {"context": "\n".join(inputs["events"]), "preparation_seconds": None}}
        for arm in ("active_memory", "zero_memory"):
            readout = predictions[(example["id"], arm)]
            arms[arm] = {"context": "Neural meeting-state readout: " + readout,
                         "raw_readout": readout, "preparation_seconds": None}
        cases.append({"id": example["id"], "synthetic": True, "query": inputs["query"],
                      "expected": example["answer"], "cohort": example.get("cohort"), "arms": arms})
    metadata = {"status": "candidate_export_no_api_calls", "openai_requests_made": 0,
                "checkpoint_path": report["selected_checkpoint"], "gold_used_for_readout": False,
                "architecture": "frozen_Qwen_features_learned_action_day_heads_typed_state",
                "test_manifest": report["test_manifest"], "limitations": report["limitations"],
                "timing_scope": "Preparation latency not measured per request; do not infer zero latency."}
    (output / "openai-cases.json").write_text(json.dumps({"metadata": metadata, "cases": cases}, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=ROOT.parent / "models/base-qwen3-0.6b")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20261026)
    parser.add_argument("--train-count", type=int, default=512)
    parser.add_argument("--development-count", type=int, default=128)
    parser.add_argument("--final-count", type=int, default=160)
    parser.add_argument("--epochs", type=int, default=120)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--encoder-batch-size", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=0.001)
    parser.add_argument("--hidden-size", type=int, default=256)
    parser.add_argument("--eval-every", type=int, default=5)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--skip-final", action="store_true", help="Development experiment only; never open final examples")
    parser.add_argument("--run-final", action="store_true", help="Explicitly evaluate final data after recipe/checkpoint selection")
    parser.add_argument("--reuse-features-from", type=Path, help="Completed development run; reuse only exact matching event text with identical base/encoder")
    args = parser.parse_args()
    if any(getattr(args, key) < 32 or getattr(args, key) % 32 for key in ("train_count", "development_count", "final_count")):
        parser.error("Data counts must be positive multiples of 32")
    if any(getattr(args, key) < 1 for key in ("epochs", "batch_size", "encoder_batch_size", "hidden_size", "eval_every")):
        parser.error("Training/encoder sizes and intervals must be positive")
    if not math.isfinite(args.learning_rate) or args.learning_rate <= 0:
        parser.error("Learning rate must be finite and positive")
    if args.output.exists():
        parser.error("Output exists; choose a fresh directory")
    if args.skip_final and args.run_final:
        parser.error("Choose --skip-final or --run-final")
    # Development-only is the default. Final data must be explicitly requested.
    args.skip_final = not args.run_final
    from robust_state_data import make_state_dataset
    args.output.mkdir(parents=True)
    torch.manual_seed(args.seed)
    torch.set_num_threads(4)
    training_data = make_state_dataset("train", args.train_count, args.seed)
    development_data = make_state_dataset("development", args.development_count, args.seed)
    training = validate_examples(training_data["examples"])
    development = validate_examples(development_data["examples"])
    (args.output / "training-data.json").write_text(json.dumps({"train": training_data, "development": development_data}, indent=2), encoding="utf-8")
    dtype = torch.bfloat16 if args.device.startswith("cuda") and torch.cuda.is_bf16_supported() else torch.float32
    loaded = time.perf_counter()
    tokenizer = AutoTokenizer.from_pretrained(args.base, local_files_only=True, trust_remote_code=False)
    base = AutoModelForCausalLM.from_pretrained(args.base, torch_dtype=dtype, attn_implementation="sdpa",
        local_files_only=True, trust_remote_code=False, use_safetensors=True).to(args.device)
    freeze_decoder(base)
    base_hash = digest_parameters(base)
    encoder = FrozenEventEncoder(base.model, tokenizer)
    model = NeuralStateMemory(StateMemoryConfig(encoder.feature_size, args.hidden_size)).to(args.device)
    report = {"status": "encoding_training", "scope": "task_specific_neural_meeting_state",
        "config": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
        "model_load_seconds": time.perf_counter() - loaded, "seed": args.seed,
        "train_count": len(training), "development_count": len(development),
        "trainable_parameters": sum(p.numel() for p in model.parameters()),
        "state_classes": list(CLASSES), "actions": list(ACTIONS), "state_bytes_fp32": 4 * len(CLASSES),
        "encoder_signature": encoder_signature(), "base_parameter_sha256_before": base_hash,
        "checkpoint_selection": "Development final-state accuracy, then action accuracy, then intermediate-state accuracy; final data generated afterward.",
        "runtime_update": "Hard argmax neural action and weekday; training uses differentiable probability updates.",
        "comparison_scope": "Active/zero/wrong are typed-state readouts; full_history is generated Qwen text. This is component recall, not a paired comparison of generated final-model answers.",
        "limitations": ["Task-specific single-meeting weekday/UNKNOWN state; not general memory.",
            "Frozen Qwen still processes each new event; no ingestion-cost or speed advantage assumed.",
            "Neural heads predict every update; no deterministic weekday/status extraction at inference.",
            "Readout is learned typed state, not the earlier 12-million-parameter soft-prefix architecture.",
            "Synthetic data supplies auxiliary action/day/intermediate-state labels during training only.",
            "SET messages explicitly name the weekday; CLEAR is unconditional; KEEP is state-independent. Implicit acceptance/coreference is outside this task.",
            "Observed benchmark parity is not a guarantee on future emails.",
            "Any final suite observed in previous experiments becomes a regression set."], "trajectory": []}
    save_report(args.output, report)
    reusable = load_reusable_features(args.reuse_features_from, base_hash, encoder.feature_size) if args.reuse_features_from else {}
    train_cache, report["training_encoding"] = cache_features(encoder, training, args.encoder_batch_size, args.device, reusable)
    dev_cache, report["development_encoding"] = cache_features(encoder, development, args.encoder_batch_size, args.device, reusable)
    torch.save({"features": train_cache, "encoder_signature": encoder_signature(), "base_parameter_sha256": base_hash}, args.output / "train-features.pt")
    torch.save({"features": dev_cache, "encoder_signature": encoder_signature(), "base_parameter_sha256": base_hash}, args.output / "development-features.pt")
    model.fit_normalizer(torch.stack(list(train_cache.values())).to(args.device))
    report["initial_development"] = evaluate(model, development, dev_cache)
    counts = Counter(label["action"] for example in training for label in example["event_labels"])
    if any(not counts[action] for action in ACTIONS):
        raise ValueError("Training data must include every action")
    weights = torch.tensor([sum(counts.values()) / (len(ACTIONS) * counts[a]) for a in ACTIONS], device=args.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=0.01)
    sampler = random.Random(args.seed)
    checkpoint = args.output / "neural-state.pt"
    best_key = (-1.0, -1.0, -1.0)
    started = time.perf_counter()
    report["status"] = "training"
    for epoch in range(1, args.epochs + 1):
        model.train()
        order = list(range(len(training)))
        sampler.shuffle(order)
        losses = []
        for offset in range(0, len(order), args.batch_size):
            selected = [training[i] for i in order[offset:offset + args.batch_size]]
            features, mask, actions, days, states = collate(selected, train_cache, args.device)
            optimizer.zero_grad(set_to_none=True)
            result = model(features, mask)
            values = supervised_loss(result, mask, actions, days, states, action_weights=weights)
            if not bool(torch.isfinite(values["loss"])):
                raise RuntimeError("Nonfinite supervised loss")
            values["loss"].backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
            optimizer.step()
            losses.append(float(values["loss"].detach()))
        if epoch == 1 or epoch % args.eval_every == 0 or epoch == args.epochs:
            checked = evaluate(model, development, dev_cache)
            metrics = checked["event_metrics"]
            key = (checked["scores"]["active_memory"]["accuracy"], metrics["action_correct"] / metrics["events"],
                   metrics["state_correct"] / metrics["events"])
            if key > best_key:
                best_key = key
                save_checkpoint(checkpoint, model, epoch, key)
            row = {"epoch": epoch, "mean_training_loss": sum(losses) / len(losses),
                   "development_state_accuracy": key[0], "development_action_accuracy": key[1],
                   "development_prefix_state_accuracy": key[2],
                   "development_set_day_accuracy": metrics["set_day_correct"] / metrics["set_events"],
                   "elapsed_seconds": time.perf_counter() - started}
            report["trajectory"].append(row)
            save_report(args.output, report)
            print(json.dumps(row), flush=True)
    report["training_seconds"] = time.perf_counter() - started
    chosen = torch.load(checkpoint, map_location=args.device, weights_only=True)
    model.load_state_dict(chosen["model_state_dict"])
    report["selected_checkpoint"] = str(checkpoint)
    report["selected_epoch"] = chosen["epoch"]
    report["development"] = evaluate(model, development, dev_cache)
    report["status"] = "checkpoint_selected"
    save_report(args.output, report)
    if not args.skip_final:
        recipe_hash = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        report["final_recipe_sha256"] = recipe_hash
        final_data = make_state_dataset("final", args.final_count, args.seed, final_recipe_sha256=recipe_hash)
        final = validate_examples(final_data["examples"])
        report["test_manifest"] = final_data["manifest"]
        report["test_count"] = len(final)
        report["test_used_for_optimization"] = False
        (args.output / "final-test-data.json").write_text(json.dumps(final_data, indent=2), encoding="utf-8")
        final_cache, report["final_encoding"] = cache_features(encoder, final, args.encoder_batch_size, args.device)
        report["test"] = evaluate(model, final, final_cache)
        report["test"]["records"].extend(full_history_records(base, tokenizer, final))
        report["test"]["scores"] = summarize_records(report["test"]["records"])
        export_api_cases(args.output, final, report["test"], report)
        report["api_export"] = str(args.output / "openai-cases.json")
    report["frozen_base_unchanged"] = digest_parameters(base) == base_hash
    report["base_has_no_gradients"] = all(p.grad is None for p in base.parameters())
    if not report["frozen_base_unchanged"] or not report["base_has_no_gradients"]:
        raise RuntimeError("Frozen base invariant failed")
    report["status"] = "development_only_completed" if args.skip_final else "completed"
    save_report(args.output, report)
    print(json.dumps({"report": str(args.output / "report.json"), "development": report["development"]["scores"],
                      "test": report.get("test", {}).get("scores"), "api_calls": 0}), flush=True)


if __name__ == "__main__":
    main()
