"""Lock two development-selected weekday writers and measure fresh v3 instances.

Local component comparison only: no training, model downloads, API calls, RAG,
or generated-answer evaluation. The final instance families are reused from v2.
Run only after both development runs are complete and the GPU is available.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gc
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import time
from typing import Any

import torch
from peft import LoraConfig, get_peft_model
from transformers import AutoModel, AutoTokenizer

from lora_state_memory import (
    LoraEventWriter, OUTCOMES, predict_events, score_examples,
    tokenizer_render_signature,
)
from train_lora_state import frozen_digest, validate_checkpoint_identity
from train_state_memory import summarize_records, validate_examples


CODE = Path(__file__).resolve().parent
SOURCE_FILES = (
    "compare_backbones.py", "robust_state_data_v3.py", "decoder_bridge.py",
    "lora_state_memory.py", "train_lora_state.py", "neural_state_memory.py",
    "train_state_memory.py", "run_experiment.py", "robust_state_data.py",
    "augment_event_data.py",
)
ARCHITECTURES = {
    "lora_Qwen_event_writer_nine_way_effect_head",
    "lora_frozen_text_event_writer_nine_way_effect_head",
}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def copy_locked_sources(output: Path, source_hashes: dict[str, str]) -> None:
    """Preserve exact runner/inference sources before opening final instances."""
    directory = output / "source"
    directory.mkdir()
    for name, expected in source_hashes.items():
        content = (CODE / name).read_bytes()
        if hashlib.sha256(content).hexdigest() != expected:
            raise ValueError("A source changed while locking the comparison")
        target = directory / name
        target.write_bytes(content)
        if sha(target) != expected:
            raise ValueError("A frozen source snapshot failed SHA-256 verification")


def _base_files(directory: Path) -> dict[str, dict[str, Any]]:
    paths = sorted(directory.glob("*.safetensors"))
    if not paths:
        raise ValueError("Base directory must contain complete local safetensors weights")
    for name in (
        "config.json", "tokenizer.json", "tokenizer_config.json",
        "special_tokens_map.json", "generation_config.json", "model.safetensors.index.json",
        "vocab.json", "merges.txt",
    ):
        path = directory / name
        if path.is_file():
            paths.append(path)
    if not (directory / "config.json").is_file():
        raise ValueError("Base config.json is missing")
    return {path.name: {"sha256": sha(path), "bytes": path.stat().st_size}
            for path in sorted(paths)}


def _tokenizer(directory: Path) -> Any:
    tokenizer = AutoTokenizer.from_pretrained(
        directory, local_files_only=True, trust_remote_code=False)
    tokenizer.padding_side = "right"
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    return tokenizer


def _initial_checkpoint_path(value: str) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path.resolve()
    candidates = {candidate.resolve() for candidate in (Path.cwd() / path, CODE.parents[1] / path)
                  if candidate.is_file()}
    if len(candidates) != 1:
        raise ValueError("Initialization checkpoint must resolve to one retained local artifact")
    return candidates.pop()


def training_chain(run: Path, frozen_hash: str) -> list[dict[str, Any]]:
    """Bind each completed parent phase to the checkpoint actually initialized."""
    phases, visited = [], set()
    current = run
    for _ in range(8):
        current = current.resolve()
        if current in visited:
            raise ValueError("Training initialization chain contains a cycle")
        visited.add(current)
        report_path, checkpoint_path = current / "report.json", current / "lora-state.pt"
        report = json.loads(report_path.read_text(encoding="utf-8"))
        if (report.get("status") != "development_only_completed"
                or report.get("test_used_for_optimization") is not False or report.get("test")
                or report.get("frozen_parameter_sha256_before") != frozen_hash):
            raise ValueError("Each training phase must be completed, development-only, and use the same frozen base")
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
        if (checkpoint.get("epoch") != report.get("selected_epoch")
                or checkpoint.get("frozen_parameter_sha256") != frozen_hash):
            raise ValueError("Training phase metadata differs from its selected checkpoint")
        files = {}
        for name in ("training-data.json", "training-augmentation.json"):
            path = current / name
            if path.is_file():
                files[name] = {"sha256": sha(path), "bytes": path.stat().st_size}
        if "training-data.json" not in files:
            raise ValueError("Every training phase must retain its train/development data")
        phases.append({
            "run_directory": str(current), "config": report["config"],
            "development_report_sha256": sha(report_path),
            "checkpoint_sha256": sha(checkpoint_path), "selected_epoch": report["selected_epoch"],
            "completed_epochs": len(report["trajectory"]), "training_data_files": files,
            "initialized_checkpoint_sha256": report.get("initialized_checkpoint_sha256"),
        })
        initial = report["config"].get("initialize_from")
        if not initial:
            phases.reverse()
            return phases
        parent = _initial_checkpoint_path(initial)
        if sha(parent) != report.get("initialized_checkpoint_sha256"):
            raise ValueError("A parent checkpoint differs from the recorded initialization hash")
        if parent.name != "lora-state.pt":
            raise ValueError("Initialization must reference a retained selected LoRA checkpoint")
        current = parent.parent
    raise ValueError("Training initialization chain exceeds eight phases")


def schedule_comparison(identities: dict[str, Any]) -> dict[str, Any]:
    fields = ("epochs", "batch_size", "rank", "learning_rate", "seed", "train_count", "augment_events")
    schedules, data_hashes = {}, {}
    for arm, identity in identities.items():
        phases = identity["training_chain"]
        schedules[arm] = [{key: phase["config"].get(key) for key in fields} for phase in phases]
        data_hashes[arm] = [{name: row["sha256"] for name, row in phase["training_data_files"].items()}
                            for phase in phases]
    return {
        "schedules": schedules,
        "matched_requested_schedule": schedules["candidate"] == schedules["reference"],
        "matched_training_data_bytes": data_hashes["candidate"] == data_hashes["reference"],
        "parent_checkpoint_links_verified": True,
        "selection_rule": "Each phase retains its development-selected checkpoint; equal requested epoch counts do not require equal selected epochs.",
    }


def selected_run(run: Path, base: Path) -> dict[str, Any]:
    """Inspect selected artifacts without a GPU or any final-instance generation."""
    run, base = run.resolve(), base.resolve()
    report_path, checkpoint_path = run / "report.json", run / "lora-state.pt"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if report.get("status") != "development_only_completed" or report.get("test"):
        raise ValueError("Requires a completed development-only run, without test selection")
    if report.get("test_used_for_optimization") is not False:
        raise ValueError("Development run must explicitly exclude test optimization")
    if report.get("architecture") not in ARCHITECTURES:
        raise ValueError("Only the nine-way LoRA event-writer architecture is supported")
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    if checkpoint.get("epoch") != report.get("selected_epoch"):
        raise ValueError("Development report and selected checkpoint epoch differ")
    expected_hash = report.get("frozen_parameter_sha256_before")
    if not isinstance(expected_hash, str) or len(expected_hash) != 64:
        raise ValueError("Development run must record its frozen-backbone digest")
    config = json.loads((base / "config.json").read_text(encoding="utf-8"))
    tokenizer = _tokenizer(base)
    signature = tokenizer_render_signature(tokenizer)
    validate_checkpoint_identity(checkpoint, checkpoint["rank"], expected_hash,
                                 signature, config.get("model_type"))
    training_files = {}
    for name in ("training-data.json", "training-augmentation.json"):
        path = run / name
        if path.is_file():
            training_files[name] = {"sha256": sha(path), "bytes": path.stat().st_size}
    if "training-data.json" not in training_files:
        raise ValueError("Selected run must retain its train/development data")
    return {
        "run_directory": str(run), "base_directory": str(base),
        "development_report_sha256": sha(report_path),
        "checkpoint_sha256": sha(checkpoint_path),
        "selected_epoch": checkpoint["epoch"], "rank": checkpoint["rank"],
        "frozen_parameter_sha256": expected_hash,
        "tokenizer_render_signature": signature,
        "checkpoint_binding": ("tokenizer-bound-v2" if checkpoint.get("tokenizer_render_signature")
                               else "verified-historical-qwen-template"),
        "model_type": config.get("model_type"), "hidden_size": config.get("hidden_size"),
        "development_scores": report["development"]["scores"],
        "training_data_files": training_files, "base_files": _base_files(base),
        "training_chain": training_chain(run, expected_hash),
    }


def verify_locked_files(identity: dict[str, Any], source_hashes: dict[str, str]) -> None:
    run, base = Path(identity["run_directory"]), Path(identity["base_directory"])
    fixed = {run / "report.json": identity["development_report_sha256"],
             run / "lora-state.pt": identity["checkpoint_sha256"]}
    fixed.update({run / name: row["sha256"] for name, row in identity["training_data_files"].items()})
    for phase in identity["training_chain"]:
        directory = Path(phase["run_directory"])
        fixed[directory / "report.json"] = phase["development_report_sha256"]
        fixed[directory / "lora-state.pt"] = phase["checkpoint_sha256"]
        fixed.update({directory / name: row["sha256"] for name, row in phase["training_data_files"].items()})
    fixed.update({base / name: row["sha256"] for name, row in identity["base_files"].items()})
    fixed.update({CODE / name: digest for name, digest in source_hashes.items()})
    for path, digest in fixed.items():
        if sha(path) != digest:
            raise ValueError(f"A locked input changed: {path.name}")


def augment_controls(result: dict[str, Any], examples: list[dict[str, Any]]) -> dict[str, Any]:
    """Add a label-blind cyclic state swap to the historical diagnostic controls."""
    rows = {row["id"]: row for row in result["records"] if row["mode"] == "active_memory"}
    for index, example in enumerate(examples):
        donor = examples[(index + 1) % len(examples)]
        prediction = rows[donor["id"]]["generated"]
        result["records"].append({
            "id": example["id"], "mode": "swapped_memory", "expected": example["answer"],
            "generated": prediction, "correct": prediction == example["answer"],
            "donor_id": donor["id"], "cohort": example["cohort"],
            "pair_id": example["pair_id"], "pair_variant": example["pair_variant"],
        })
    result["scores"] = summarize_records(result["records"])
    result["controls"] = {
        "zero_memory": "Erase memory to UNKNOWN for every case; no labels select this control.",
        "swapped_memory": "Use the next case's predicted final state in locked dataset order, wrapping at the end; labels do not select donors.",
        "wrong_memory": "Historical evaluation-only control: score_examples selects the first donor whose gold answer differs. Gold is used to choose this control donor after inference, never to predict or update memory.",
    }
    result["by_cohort"] = {}
    for cohort in sorted({row["cohort"] for row in result["records"]}):
        result["by_cohort"][cohort] = summarize_records(
            [row for row in result["records"] if row["cohort"] == cohort])
    metrics = result["event_metrics"]
    result["event_rates"] = {
        "event_action_accuracy": metrics["action_correct"] / metrics["events"],
        "prefix_state_accuracy": metrics["state_correct"] / metrics["events"],
        "set_day_accuracy": metrics["set_day_correct"] / metrics["set_events"],
    }
    return result


def paired_scores(candidate: dict[str, Any], reference: dict[str, Any]) -> dict[str, Any]:
    def records(result: dict[str, Any]) -> dict[str, Any]:
        return {row["id"]: row for row in result["records"] if row["mode"] == "active_memory"}
    left, right = records(candidate), records(reference)
    if set(left) != set(right):
        raise ValueError("Paired arms do not cover the same planned examples")
    counts = Counter()
    regressions, improvements = [], []
    groups = defaultdict(list)
    for identifier in left:
        a, b = left[identifier], right[identifier]
        if a["expected"] != b["expected"]:
            raise ValueError("Paired arms disagree about a scoring label")
        if a["correct"] and b["correct"]:
            counts["both_correct"] += 1
        elif a["correct"]:
            counts["candidate_only_correct"] += 1
            improvements.append(identifier)
        elif b["correct"]:
            counts["reference_only_correct"] += 1
            regressions.append(identifier)
        else:
            counts["both_wrong"] += 1
        groups[a["pair_id"]].append(identifier)
    if any(len(identifiers) != 2 for identifiers in groups.values()):
        raise ValueError("Counterfactual pair groups must contain exactly two cases")
    return {
        "planned_cases": len(left), **{key: counts[key] for key in (
            "both_correct", "candidate_only_correct", "reference_only_correct", "both_wrong")},
        "improvements": improvements, "regressions": regressions,
        "accuracy_difference_candidate_minus_reference": (
            sum(row["correct"] for row in left.values()) - sum(row["correct"] for row in right.values())
        ) / len(left),
        "counterfactual_pairs": len(groups),
        "candidate_both_variants_correct": sum(all(left[i]["correct"] for i in ids) for ids in groups.values()),
        "reference_both_variants_correct": sum(all(right[i]["correct"] for i in ids) for ids in groups.values()),
        "uncertainty": "Paired variants are dependent; no independent-case significance or generalization claim is made.",
    }


def _synchronize(device: str) -> None:
    if torch.device(device).type == "cuda":
        torch.cuda.synchronize(device)


def evaluate_identity(identity: dict[str, Any], examples: list[dict[str, Any]], *,
                      device: str, dtype: torch.dtype, batch_size: int) -> dict[str, Any]:
    """Load and release one backbone at a time; labels are accessed after prediction."""
    base = adapted = model = tokenizer = None
    started = time.perf_counter()
    try:
        run, directory = Path(identity["run_directory"]), Path(identity["base_directory"])
        checkpoint = torch.load(run / "lora-state.pt", map_location="cpu", weights_only=True)
        tokenizer = _tokenizer(directory)
        base = AutoModel.from_pretrained(directory, torch_dtype=dtype,
            attn_implementation="sdpa", local_files_only=True, trust_remote_code=False,
            use_safetensors=True).to(device)
        rank = checkpoint["rank"]
        adapted = get_peft_model(base, LoraConfig(
            r=rank, lora_alpha=2 * rank, lora_dropout=0.05,
            target_modules=["q_proj", "v_proj", "o_proj"],
            bias="none", task_type="FEATURE_EXTRACTION"))
        model = LoraEventWriter(adapted).to(device)
        before = frozen_digest(model)
        validate_checkpoint_identity(checkpoint, rank, before,
            tokenizer_render_signature(tokenizer), base.config.model_type)
        if before != identity["frozen_parameter_sha256"]:
            raise ValueError("Loaded backbone differs from locked training digest/dtype")
        learned = {name: p for name, p in model.named_parameters() if p.requires_grad}
        values = checkpoint["trainable_state_dict"]
        if set(learned) != set(values):
            raise ValueError("Checkpoint does not exactly cover adapters and classifier head")
        with torch.no_grad():
            for name, parameter in learned.items():
                value = values[name]
                if value.shape != parameter.shape or value.dtype != parameter.dtype or not bool(torch.isfinite(value).all()):
                    raise ValueError("Learned tensor geometry/dtype/values mismatch")
                parameter.copy_(value.to(device))
        model.eval()
        _synchronize(device)
        load_seconds = time.perf_counter() - started
        # Only raw event strings enter predict_events. Annotations are used below.
        events = list(dict.fromkeys(event for row in examples for event in row["events"]))
        started = time.perf_counter()
        predictions = predict_events(model, tokenizer, events, batch_size=batch_size)
        _synchronize(device)
        inference_seconds = time.perf_counter() - started
        scored = augment_controls(score_examples(examples, predictions), examples)
        after = frozen_digest(model)
        no_frozen_gradients = all(p.grad is None for p in model.parameters() if not p.requires_grad)
        if before != after or not no_frozen_gradients:
            raise RuntimeError("Frozen-backbone invariant failed during inference")
        return {
            "status": "completed", "test": scored,
            "event_predictions": [{"text": event, "outcome": predictions[event]} for event in events],
            "unique_events_inferred": len(events),
            "event_occurrences_scored": sum(len(row["events"]) for row in examples),
            "model_load_seconds": load_seconds, "batched_unique_event_inference_seconds": inference_seconds,
            "timing_scope": "Sequential model loading and batched deduplicated event inference; not uncached per-workflow latency. No speedup claim.",
            "frozen_base_unchanged": before == after,
            "base_has_no_gradients": no_frozen_gradients,
            "frozen_parameter_sha256_before": before, "frozen_parameter_sha256_after": after,
            "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad),
            "frozen_parameters": sum(p.numel() for p in model.parameters() if not p.requires_grad),
        }
    finally:
        model = adapted = base = tokenizer = None
        gc.collect()
        if torch.device(device).type == "cuda":
            torch.cuda.empty_cache()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-run", type=Path, required=True)
    parser.add_argument("--candidate-base", type=Path, required=True)
    parser.add_argument("--reference-run", type=Path, required=True)
    parser.add_argument("--reference-base", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--dtype", choices=("auto", "float32", "bfloat16"), default="auto")
    parser.add_argument("--prepare-only", action="store_true",
                        help="Lock inputs only; do not generate final instances or load model weights")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Choose a fresh output directory; existing comparisons are never overwritten")
    if args.batch_size < 1:
        parser.error("batch-size must be positive")
    torch.set_num_threads(4)
    torch.manual_seed(20261028)
    dtype_name = args.dtype
    if dtype_name == "auto":
        dtype_name = ("bfloat16" if args.device.startswith("cuda") and torch.cuda.is_bf16_supported()
                      else "float32")
    dtype = getattr(torch, dtype_name)
    identities = {
        "candidate": selected_run(args.candidate_run, args.candidate_base),
        "reference": selected_run(args.reference_run, args.reference_base),
    }
    source_hashes = {name: sha(CODE / name) for name in SOURCE_FILES}
    recipe = {
        "schema": "weekday-backbone-comparison-recipe-v1",
        "status": "locked_before_final_generation",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "arms": identities, "source_hashes": source_hashes,
        "source_snapshot_directory": "source",
        "training_schedule_comparison": schedule_comparison(identities),
        "generator": {"module": "robust_state_data_v3", "count": 160, "seed": 20261028,
                      "wording_families_reused_from_v2": True},
        "runtime": {"device": args.device, "dtype": dtype_name, "batch_size": args.batch_size,
                    "order": ["candidate", "reference"], "model_concurrency": 1},
        "packages": {name: version(name) for name in ("torch", "transformers", "peft")},
        "scope": "Weekday/CLEAR/KEEP state component only; not RAG or generated answers.",
        "selection": "Use already-selected development checkpoints as provided. No 100% development gate. No final tuning.",
        "controls": ["zero_memory", "wrong_memory (gold-selected evaluation donor)",
                     "swapped_memory (label-blind next-case cyclic donor)"],
        "api_calls": 0,
    }
    args.output.mkdir(parents=True)
    copy_locked_sources(args.output, source_hashes)
    recipe_path = args.output / "locked-recipe.json"
    write_json(recipe_path, recipe)
    recipe_hash = sha(recipe_path)
    if args.prepare_only:
        print(json.dumps({"status": "prepared", "recipe_sha256": recipe_hash,
                          "final_generated": False, "model_forwards": 0, "api_calls": 0}))
        return
    from robust_state_data_v3 import make_state_dataset
    # Only after both checkpoints, all local base artifacts and source are locked.
    dataset = make_state_dataset("final", 160, 20261028, final_recipe_sha256=recipe_hash)
    examples = validate_examples(dataset["examples"])
    data_path = args.output / "final-test-data.json"
    write_json(data_path, dataset)
    report: dict[str, Any] = {
        "schema": "weekday-backbone-comparison-v1", "status": "measuring",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "recipe_sha256": recipe_hash, "dataset_sha256": sha(data_path),
        "test_manifest": dataset["manifest"], "arms": {}, "planned_cases_per_arm": 160,
        "training_schedule_comparison": recipe["training_schedule_comparison"],
        "test_used_for_optimization": False, "api_calls": 0,
        "comparison_scope": "Trained LoRA event-effect classifier and weekday/UNKNOWN replay component; no reader generation, RAG, general workflow or equal-accuracy claim.",
        "limitations": [
            "Fresh seeded instances intentionally reuse v2 final wording families; not unseen-family generalization.",
            "A single meeting with explicit weekday confirmations; no multi-entity facts or implicit acceptance.",
            "Selected models may have different training histories, parameter counts and development quality; this is not an isolated causal test of backbone choice.",
            "Both state arms and diagnostic controls score all 160 cases; counterfactual pairs are dependent observations.",
            "Earlier test evidence may have been inspected during development; a seed refresh does not erase that historical knowledge.",
        ],
    }
    report_path = args.output / "report.json"
    write_json(report_path, report)
    try:
        for arm in ("candidate", "reference"):
            verify_locked_files(identities[arm], source_hashes)
            print(json.dumps({"arm": arm, "status": "loading", "planned_cases": 160}), flush=True)
            report["arms"][arm] = evaluate_identity(identities[arm], examples,
                device=args.device, dtype=dtype, batch_size=args.batch_size)
            write_json(report_path, report)
            print(json.dumps({"arm": arm, "status": "completed",
                              "scores": report["arms"][arm]["test"]["scores"]}), flush=True)
        report["paired"] = paired_scores(report["arms"]["candidate"]["test"],
                                          report["arms"]["reference"]["test"])
        report["status"] = "completed"
        report["completed_at"] = datetime.now(timezone.utc).isoformat()
        write_json(report_path, report)
    except Exception as exc:
        report.update(status="failed", error_type=type(exc).__name__)
        write_json(report_path, report)
        raise
    print(json.dumps({"report": str(report_path.resolve()), "paired": report["paired"],
                      "api_calls": 0}), flush=True)


if __name__ == "__main__":
    main()
