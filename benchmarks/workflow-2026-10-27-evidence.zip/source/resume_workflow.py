"""Explicit operational continuation of an interrupted, frozen workflow run.

Prepare first, review the recovery manifest, then execute the same prepared
directory with that manifest. Existing attempts are replayed locally, never
retried. The frozen experiment runner and original run files remain unchanged.
"""
from __future__ import annotations

import argparse
import copy
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import math
from pathlib import Path
import shutil
import time

import run_workflow as frozen


SCHEMA = "workflow-operational-recovery-v1"
SOURCE_FILES = ("report.json", "request-plan.json", "requests.jsonl", "responses.jsonl")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def call_key(row):
    if row.get("stage") == "updater":
        return (row["workflow_id"], "updater", row["chunk_index"])
    if row.get("stage") == "reader":
        return (row["workflow_id"], "reader", row["query_id"], row["arm"])
    raise ValueError("Unknown call stage")


def same_request(request, recorded):
    # Canonical outer JSON bytes; the instructions and input strings themselves
    # must be identical, including whitespace and every source event character.
    raw = frozen.canonical(request).encode("utf-8")
    if raw != frozen.canonical(recorded["request"]).encode("utf-8"):
        raise ValueError("Reconstructed request differs from the original attempt")
    if hashlib.sha256(raw).hexdigest() != recorded["request_sha256"]:
        raise ValueError("Original request checksum mismatch")


def load_source(source, dataset_path, protocol_path, count_tokens):
    source = Path(source).resolve()
    report = read_json(source / "report.json")
    plan = read_json(source / "request-plan.json")
    protocol = read_json(protocol_path)
    if not report.get("status", "").startswith("stopped_") or report.get("in_flight"):
        raise ValueError("Recovery requires a stopped and drained original run")
    if (frozen.sha(dataset_path) != report["dataset_sha256"]
            or frozen.sha(protocol_path) != report["protocol_sha256"]
            or frozen.sha(source / "request-plan.json") != report["request_plan_sha256"]):
        raise ValueError("Original source hashes do not match")
    spec = frozen.protocol_spec()
    if report["runner"] != spec or plan["runner"] != spec or protocol["workflow_runner"] != spec:
        raise ValueError("The frozen runner, settings or prompts changed")
    if (protocol["dataset_sha256"] != report["dataset_sha256"]
            or protocol["max_cost_usd"] != report["max_cost_usd"]
            or protocol["concurrency"] != report["concurrency"]
            or plan["order_seed"] != protocol["seed"]):
        raise ValueError("Original protocol settings disagree")
    data = frozen.load_dataset(dataset_path, count_tokens)
    rebuilt, estimate = frozen.make_plan(data, count_tokens, protocol["seed"])
    if rebuilt != plan["plan"] or estimate != plan["budget_estimate"]:
        raise ValueError("Original request plan cannot be reconstructed")
    requests = [json.loads(line) for line in (source / "requests.jsonl").read_text(encoding="utf-8").splitlines()]
    responses = [json.loads(line) for line in (source / "responses.jsonl").read_text(encoding="utf-8").splitlines()]
    by_id, by_key, response_by_id = {}, {}, {}
    for row in requests:
        if row["call_id"] in by_id or call_key(row) in by_key:
            raise ValueError("Duplicate original request ID or semantic request key")
        by_id[row["call_id"]] = row
        by_key[call_key(row)] = row
        same_request(row["request"], row)
    response_ids = set()
    for row in responses:
        if row["call_id"] in response_by_id or row["call_id"] not in by_id:
            raise ValueError("Duplicate or unmatched original response")
        if call_key(row) != call_key(by_id[row["call_id"]]):
            raise ValueError("Original response metadata disagrees with its request")
        response_by_id[row["call_id"]] = row
        response_id = row.get("response_id")
        if response_id:
            if response_id in response_ids:
                raise ValueError("Duplicate provider response ID")
            response_ids.add(response_id)
        for key, calculated in (("estimated_api_cost_usd", frozen.poc.token_cost(row)),
                                ("budget_accounted_cost_usd", frozen.poc.budget_token_cost(row))):
            recorded = row.get(key)
            if (recorded is None) != (calculated is None) or (recorded is not None and not math.isclose(recorded, calculated, abs_tol=1e-12)):
                raise ValueError("Original cost does not match recorded usage")
    if set(response_by_id) != set(by_id):
        raise ValueError("An attempted request lacks a recorded response; manual resolution is required")
    recorded_calls = report["calls"]
    if (len(recorded_calls) != len(response_by_id)
            or {row["call_id"]: row for row in recorded_calls} != response_by_id):
        raise ValueError("Original report and response journal disagree")
    state = {"source": source, "report": report, "plan": plan, "protocol": protocol, "data": data,
             "requests": requests, "by_id": by_id, "by_key": by_key, "response_by_id": response_by_id}
    snapshot = seeded_budget(state).snapshot()
    for key, expected in report["run_budget"].items():
        actual = snapshot[key]
        if isinstance(actual, float):
            if not math.isclose(actual, expected, abs_tol=1e-12):
                raise ValueError("Original budget snapshot does not reconcile")
        elif actual != expected:
            raise ValueError("Original budget snapshot does not reconcile")
    return state


def seeded_budget(state):
    budget = frozen.RunBudget(state["report"]["max_cost_usd"])
    for request in state["requests"]:
        identifier = request["call_id"]
        if not budget.reserve(identifier, frozen.maximum_request_cost(request["request"])):
            raise ValueError("Original attempts cannot fit the original run cap")
        result = state["response_by_id"][identifier]
        budget.settle(identifier, result["budget_accounted_cost_usd"], request_started=result["request_started"])
    return budget


def preflight(state, count_tokens):
    """Replay every reconstructable old payload without consulting gold values."""
    visited, pending, failures = set(), [], []
    by_workflow = {row["workflow_id"]: row for row in state["plan"]["plan"]}
    for workflow in state["data"]["workflows"]:
        current = frozen.initial_state(workflow["entity_catalog"])
        keys = frozen.catalog_keys(workflow["entity_catalog"])
        memory_known, memory_valid = True, True
        for index, chunk in enumerate(frozen.chunks_for(workflow["events"], count_tokens)):
            metadata = {"workflow_id": workflow["id"], "stage": "updater", "chunk_index": index}
            old = state["by_key"].get(call_key(metadata))
            if not memory_valid:
                if old:
                    raise ValueError("Recorded updater follows a failed memory pipeline")
                continue
            if old is None:
                memory_known = False
                pending.append(metadata)
                continue
            if not memory_known:
                raise ValueError("An original updater is missing its predecessor")
            same_request(frozen.update_payload(workflow, current, chunk), old)
            visited.add(old["call_id"])
            result = state["response_by_id"][old["call_id"]]
            allowed = {identifier for fact in current["facts"] for identifier in fact["evidence_event_ids"]}
            allowed.update(event["event_id"] for event in chunk)
            if result["status"] != "completed":
                memory_valid = False
                failures.append(old["call_id"])
                continue
            try:
                current = frozen.validate_facts(result["text"], keys, allowed, memory=True)
            except (ValueError, TypeError, KeyError):
                memory_valid = False
        for query, planned in zip(workflow["queries"], by_workflow[workflow["id"]]["queries"]):
            for arm in planned["arm_order"]:
                metadata = {"workflow_id": workflow["id"], "stage": "reader", "query_id": query["query_id"], "arm": arm}
                old = state["by_key"].get(call_key(metadata))
                if arm == "active_memory" and not memory_valid:
                    if old:
                        raise ValueError("Original memory reader follows a failed updater")
                    continue
                if old is None:
                    pending.append(metadata)
                    continue
                if arm == "active_memory" and not memory_known:
                    raise ValueError("Original memory reader precedes complete recorded ingestion")
                same_request(frozen.reader_payload(workflow, query, arm, current, count_tokens), old)
                visited.add(old["call_id"])
                if state["response_by_id"][old["call_id"]]["status"] != "completed":
                    failures.append(old["call_id"])
    if visited != set(state["by_id"]):
        raise ValueError("Some original calls are not reachable in the frozen plan")
    return {"verified_original_requests": len(visited), "retained_failed_call_ids": failures,
            "maximum_unattempted_requests": len(pending), "unattempted_requests": pending,
            "initial_budget": seeded_budget(state).snapshot(),
            "next_call_number": max((int(row["call_id"].removeprefix("call-")) for row in state["requests"]), default=-1) + 1}


def recovery_manifest(state, check, dataset_path, protocol_path, output):
    return {"schema": SCHEMA, "driver_sha256": frozen.sha(__file__),
            "output_directory": str(Path(output).resolve()), "source_directory": str(state["source"]),
            "source_sha256": {name: frozen.sha(state["source"] / name) for name in SOURCE_FILES},
            "dataset_sha256": frozen.sha(dataset_path), "protocol_sha256": frozen.sha(protocol_path),
            "frozen_runner_sha256": frozen.sha(frozen.__file__),
            "original_run_cap_usd": state["report"]["max_cost_usd"],
            "maximum_new_commitment_usd": check["initial_budget"]["available_usd"],
            "original_known_spend_usd": check["initial_budget"]["known_spend_usd"],
            "original_unknown_hold_usd": check["initial_budget"]["unknown_hold_usd"],
            "next_call_number": check["next_call_number"], "concurrency": state["report"]["concurrency"],
            "policy": "Replay prior attempts exactly without transport or new reservations; failed attempts remain failed. Dispatch only previously unattempted request keys. Preserve the original unknown hold. Any new provider/usage/budget failure stops dispatch.",
            "timing_policy": "Aggregate ingestion_seconds is the sum of recorded updater API seconds across original and continuation segments. Original ingestion wall time is retained separately when available. Replay CPU time is excluded. The interruption changes cache and concurrency conditions."}


class RecoveryExperiment(frozen.Experiment):
    def __init__(self, output, state, manifest, *, key="", ledger_path=None):
        report = copy.deepcopy(state["report"])
        report.update(status="prepared_recovery_no_api_calls", query_results=[], workflow_results=[], in_flight=[])
        report.pop("error", None)
        report.pop("elapsed_run_seconds", None)
        report["recovery"] = {"schema": SCHEMA, "manifest": manifest,
                              "manifest_sha256": frozen.sha(Path(output) / "recovery-manifest.json"),
                              "original_status": state["report"]["status"],
                              "original_error": state["report"].get("error"),
                              "original_call_count": len(report["calls"]),
                              "original_elapsed_run_seconds": state["report"].get("elapsed_run_seconds")}
        report["notes"] += ["An explicit operational continuation followed the original stopped run. Original attempts, including provider failures, remain unchanged and were not retried. New transport is limited to previously unattempted requests.",
                            manifest["timing_policy"],
                            "Known API spend excludes the cost of the retained unknown-usage failure. Its conservative reservation remains held in both run and project budgets."]
        super().__init__(output, report, state["data"]["workflows"], key=key, ledger_path=ledger_path,
                         max_cost=state["report"]["max_cost_usd"])
        self.source_state = state
        self.budget = seeded_budget(state)
        self.counter = manifest["next_call_number"]
        self.replayed_ids, self.new_keys = set(), set()
        self.old_workflows = {row["workflow_id"]: row for row in state["report"]["workflow_results"]}

    def call(self, request, metadata):
        key = call_key(metadata)
        with self.lock:
            old = self.source_state["by_key"].get(key)
            if old is not None:
                same_request(request, old)
                if old["call_id"] in self.replayed_ids:
                    raise ValueError("Duplicate replay")
                self.replayed_ids.add(old["call_id"])
                # Crucially do not set the global stop for a historical failure.
                # Its failed query slot is reconstructed by the frozen scorer.
                return copy.deepcopy(self.source_state["response_by_id"][old["call_id"]])
            if key in self.new_keys:
                raise ValueError("Duplicate continuation dispatch")
            self.new_keys.add(key)
        return super().call(request, metadata)

    def save(self):
        with self.lock:
            for row in self.report["workflow_results"]:
                if "ingestion_timing_basis" not in row:
                    original = self.old_workflows.get(row["workflow_id"])
                    row["original_ingestion_wall_seconds"] = original.get("original_ingestion_wall_seconds", original["ingestion_seconds"]) if original else None
                    row["original_ingestion_status"] = original.get("original_ingestion_status", original["memory_status"]) if original else None
                    row["ingestion_timing_basis"] = "sum_of_recorded_updater_api_seconds_across_segments"
                    row["ingestion_seconds"] = row["ingestion_api_seconds"]
            self.report["recovery"]["replayed_original_calls"] = len(self.replayed_ids)
            self.report["recovery"]["new_recorded_calls"] = len(self.report["calls"]) - len(self.source_state["report"]["calls"])
            super().save()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-run", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--execute", action="store_true")
    parser.add_argument("--amendment", type=Path)
    parser.add_argument("--saved-key", action="store_true")
    parser.add_argument("--budget-ledger", type=Path)
    args = parser.parse_args(argv)
    if args.output.resolve() == args.source_run.resolve():
        parser.error("Recovery must use a separate output directory")
    counter = frozen.token_counter()
    state = load_source(args.source_run, args.dataset, args.protocol, counter)
    check = preflight(state, counter)
    manifest = recovery_manifest(state, check, args.dataset, args.protocol, args.output)
    if args.prepare_only:
        if args.output.exists():
            parser.error("Preparation requires a fresh output directory")
        args.output.mkdir(parents=True)
        for name in SOURCE_FILES:
            shutil.copyfile(args.source_run / name, args.output / ("original-report.json" if name == "report.json" else name))
        write_json(args.output / "recovery-manifest.json", manifest)
        write_json(args.output / "recovery-preflight.json", check)
        experiment = RecoveryExperiment(args.output, state, manifest)
        experiment.save()
        print(json.dumps({"status": "prepared_recovery_no_api_calls", "manifest": str(args.output / "recovery-manifest.json"),
                          "verified_original_requests": check["verified_original_requests"],
                          "maximum_unattempted_requests": check["maximum_unattempted_requests"],
                          "initial_budget": check["initial_budget"]}, indent=2))
        return 0
    if not args.saved_key or args.budget_ledger is None or args.amendment is None:
        parser.error("Execution requires the reviewed --amendment, --saved-key and existing --budget-ledger")
    if (read_json(args.amendment) != manifest
            or read_json(args.output / "recovery-manifest.json") != manifest
            or read_json(args.output / "report.json")["status"] != "prepared_recovery_no_api_calls"):
        parser.error("The reviewed recovery manifest or prepared state changed")
    for name in SOURCE_FILES:
        target = args.output / ("original-report.json" if name == "report.json" else name)
        if frozen.sha(target) != manifest["source_sha256"][name]:
            parser.error("Prepared evidence changed or continuation was already attempted")
    experiment = RecoveryExperiment(args.output, state, manifest, ledger_path=args.budget_ledger)
    experiment.report["recovery"]["project_budget_before_continuation"] = frozen.poc.project_budget_snapshot(args.budget_ledger)
    experiment.key = frozen.poc.load_saved_api_key()
    if not isinstance(experiment.key, str) or not experiment.key or not experiment.key.isascii() or any(ord(c) <= 32 or ord(c) == 127 for c in experiment.key):
        raise ValueError("Saved key unavailable")
    experiment.report["status"] = "running_operational_continuation"
    experiment.save()
    by_id = {row["id"]: row for row in state["data"]["workflows"]}
    started = time.perf_counter()
    try:
        with ThreadPoolExecutor(max_workers=manifest["concurrency"]) as pool:
            futures = [pool.submit(experiment.run_workflow, by_id[item["workflow_id"]], item, counter) for item in state["plan"]["plan"]]
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as exc:
                    experiment.stop.set()
                    experiment.report["status"] = "stopped_recovery_internal_error"
                    experiment.report["error"] = "Continuation processing failed: " + type(exc).__name__ + ". No retry was made."
                    experiment.save()
        if not experiment.stop.is_set():
            if experiment.replayed_ids != set(state["by_id"]):
                raise ValueError("Not all original attempts were replayed")
            experiment.report["status"] = "completed"
    finally:
        experiment.key = ""
        experiment.report["elapsed_run_seconds"] = time.perf_counter() - started
        experiment.report["recovery"]["continuation_elapsed_scope"] = "Includes offline replay and new requests; not a single uninterrupted experiment wall time"
        experiment.report["project_budget_after"] = frozen.poc.project_budget_snapshot(args.budget_ledger)
        experiment.save()
    print(json.dumps({"status": experiment.report["status"], "report": str(args.output / "report.json"),
                      "run_budget": experiment.report["run_budget"]}, indent=2))
    return 0 if experiment.report["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
